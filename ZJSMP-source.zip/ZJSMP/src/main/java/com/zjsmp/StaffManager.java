package com.zjsmp;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/** Staff mode hotbar, vanish, freeze, better view, staff chat and alerts. */
final class StaffManager {

    private final ZJSMP plugin;
    private final File file;
    private final YamlConfiguration data;
    private final NamespacedKey toolKey;

    private final Set<UUID> staffMode = new HashSet<>();
    private final Set<UUID> vanished = new HashSet<>();
    private final Set<UUID> frozen = new HashSet<>();
    private final Set<UUID> betterView = new HashSet<>();
    final Set<UUID> staffChatToggle = new HashSet<>();

    StaffManager(ZJSMP plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "staffmode.yml");
        this.data = YamlConfiguration.loadConfiguration(file);
        this.toolKey = new NamespacedKey(plugin, "tool");
    }

    private void save() {
        try {
            plugin.getDataFolder().mkdirs();
            data.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("Could not save staffmode.yml: " + e.getMessage());
        }
    }

    /** Repeating action bar for vanished / frozen players. */
    void start() {
        Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (plugin.getConfig().getBoolean("staff-mode.vanish-actionbar.enabled", true)) {
                Component msg = plugin.c(plugin.getConfig().getString("staff-mode.vanish-actionbar.message", "&aVANISHED"));
                for (UUID id : vanished) {
                    Player p = Bukkit.getPlayer(id);
                    if (p != null) p.sendActionBar(msg);
                }
            }
            Component fz = plugin.c("&c&lYOU ARE FROZEN &7- do not log out");
            for (UUID id : frozen) {
                Player p = Bukkit.getPlayer(id);
                if (p != null) p.sendActionBar(fz);
            }
        }, 40L, 40L);
    }

    // ------------------------------------------------------------ queries

    boolean inStaffMode(Player p) { return staffMode.contains(p.getUniqueId()); }
    boolean isVanished(Player p) { return vanished.contains(p.getUniqueId()); }
    boolean isFrozen(Player p) { return frozen.contains(p.getUniqueId()); }
    int vanishedCount() { return vanished.size(); }

    String toolId(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return null;
        return item.getItemMeta().getPersistentDataContainer().get(toolKey, PersistentDataType.STRING);
    }

    // ------------------------------------------------------------ join / quit

    void onJoin(Player p) {
        UUID id = p.getUniqueId();
        if (data.contains("staff." + id)) {
            staffMode.add(id);
            if (!p.hasPermission("zjsmp.staffmode")) {
                disable(p); // lost the permission while offline: give their stuff back
            } else if (data.getBoolean("staff." + id + ".vanished")) {
                vanished.add(id);
                p.setSleepingIgnored(true);
                p.setCollidable(false);
            }
        }
        refreshVisibility();
    }

    void onQuit(Player p) {
        UUID id = p.getUniqueId();
        staffMode.remove(id);
        vanished.remove(id);
        betterView.remove(id);
        staffChatToggle.remove(id);
    }

    // ------------------------------------------------------------ staff mode

    void enable(Player p) {
        UUID id = p.getUniqueId();
        if (!staffMode.add(id)) return;

        ItemStack[] contents = p.getInventory().getContents();
        for (int i = 0; i < contents.length; i++) {
            if (contents[i] == null) contents[i] = new ItemStack(Material.AIR);
        }
        String base = "staff." + id;
        data.set(base + ".inv", Base64.getEncoder().encodeToString(ItemStack.serializeItemsAsBytes(contents)));
        data.set(base + ".gamemode", p.getGameMode().name());
        data.set(base + ".allowflight", p.getAllowFlight());
        data.set(base + ".vanished", false);
        save();

        p.getInventory().clear();
        giveTools(p);
        plugin.send(p, "&aStaff mode enabled.");
        if (plugin.getConfig().getBoolean("staff-mode.auto-vanish-on-enable", false)) setVanish(p, true, true);
    }

    void disable(Player p) {
        UUID id = p.getUniqueId();
        if (!staffMode.remove(id)) return;
        if (betterView.contains(id)) toggleBetterView(p);
        if (vanished.contains(id)) setVanish(p, false, true);

        String base = "staff." + id;
        String inv = data.getString(base + ".inv");
        p.getInventory().clear();
        if (inv != null) {
            try {
                p.getInventory().setContents(ItemStack.deserializeItemsFromBytes(Base64.getDecoder().decode(inv)));
            } catch (RuntimeException e) {
                plugin.getLogger().warning("Could not restore inventory for " + p.getName() + ": " + e.getMessage());
            }
        }
        try {
            p.setGameMode(GameMode.valueOf(data.getString(base + ".gamemode", "SURVIVAL")));
        } catch (IllegalArgumentException ignored) { }
        p.setAllowFlight(data.getBoolean(base + ".allowflight", false));

        data.set("staff." + id, null);
        save();
        plugin.send(p, "&cStaff mode disabled.");
    }

    void toggle(Player p) {
        if (inStaffMode(p)) disable(p); else enable(p);
    }

    private ItemStack tool(String id, Material mat, String name, String... lore) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(plugin.c(name).decoration(TextDecoration.ITALIC, false));
        meta.lore(Arrays.stream(lore).map(l -> plugin.c(l).decoration(TextDecoration.ITALIC, false)).toList());
        meta.getPersistentDataContainer().set(toolKey, PersistentDataType.STRING, id);
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack vanishItem(boolean on) {
        return on
                ? tool("vanish", Material.LIME_DYE, "&aVanished", "&7Click to disable vanish")
                : tool("vanish", Material.GRAY_DYE, "&7Unvanished", "&7Click to enable vanish");
    }

    private int slot(String key, int def) {
        return plugin.getConfig().getInt("staff-mode.slots." + key, def);
    }

    void giveTools(Player p) {
        var inv = p.getInventory();
        inv.setItem(slot("vanish", 0), vanishItem(vanished.contains(p.getUniqueId())));
        inv.setItem(slot("freeze", 1), tool("freeze", Material.ICE, "&bFreeze Player",
                "&7Right-click a player to freeze them"));
        inv.setItem(slot("stafflist", 4), tool("stafflist", Material.CLOCK, "&eStaff List",
                "&7Click to view online staff"));
        inv.setItem(slot("betterview", 7), tool("betterview", Material.ORANGE_CARPET, "&eBetter View",
                "&7Click to toggle night vision + flight"));
        inv.setItem(slot("randomtp", 8), tool("randomtp", Material.COMPASS, "&aRandom Teleport",
                "&7Click to teleport to a random player"));
    }

    // ------------------------------------------------------------ vanish

    void toggleVanish(Player p) {
        setVanish(p, !vanished.contains(p.getUniqueId()), true);
    }

    void setVanish(Player p, boolean on, boolean announce) {
        UUID id = p.getUniqueId();
        if (on == vanished.contains(id)) return;
        if (on) vanished.add(id); else vanished.remove(id);

        if (data.contains("staff." + id)) {
            data.set("staff." + id + ".vanished", on);
            save();
        }
        p.setSleepingIgnored(on);
        p.setCollidable(!on);

        if (!on) {
            for (Player viewer : Bukkit.getOnlinePlayers()) viewer.showPlayer(plugin, p);
        }
        refreshVisibility();

        if (announce && plugin.getConfig().getBoolean("staff-mode.fake-leave-join-messages", true)) {
            Component msg = Component.translatable(on ? "multiplayer.player.left" : "multiplayer.player.joined",
                    NamedTextColor.YELLOW, Component.text(p.getName()));
            for (Player o : Bukkit.getOnlinePlayers()) {
                if (!o.hasPermission("zjsmp.seevanished")) o.sendMessage(msg);
            }
        }
        if (staffMode.contains(id)) {
            p.getInventory().setItem(slot("vanish", 0), vanishItem(on));
        }
        plugin.send(p, on ? "&aYou are now vanished." : "&cYou are no longer vanished.");
    }

    /** Hides vanished players from everyone who lacks zjsmp.seevanished. */
    void refreshVisibility() {
        for (Player viewer : Bukkit.getOnlinePlayers()) {
            for (UUID id : vanished) {
                Player v = Bukkit.getPlayer(id);
                if (v == null || v.equals(viewer)) continue;
                if (viewer.hasPermission("zjsmp.seevanished")) viewer.showPlayer(plugin, v);
                else viewer.hidePlayer(plugin, v);
            }
        }
    }

    // ------------------------------------------------------------ better view

    void toggleBetterView(Player p) {
        UUID id = p.getUniqueId();
        if (betterView.remove(id)) {
            p.removePotionEffect(PotionEffectType.NIGHT_VISION);
            boolean keep = p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SPECTATOR;
            p.setAllowFlight(keep);
            plugin.send(p, "&cBetter view disabled.");
        } else {
            betterView.add(id);
            p.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, PotionEffect.INFINITE_DURATION,
                    0, false, false, false));
            p.setAllowFlight(true);
            p.setFlying(true);
            plugin.send(p, "&aBetter view enabled.");
        }
    }

    // ------------------------------------------------------------ random tp

    void randomTp(Player p) {
        List<Player> candidates = new ArrayList<>();
        for (Player o : Bukkit.getOnlinePlayers()) {
            if (o.equals(p) || vanished.contains(o.getUniqueId()) || o.hasPermission("zjsmp.staff")) continue;
            candidates.add(o);
        }
        if (candidates.isEmpty()) {
            plugin.send(p, "&cNo players to teleport to.");
            return;
        }
        Player t = candidates.get(ThreadLocalRandom.current().nextInt(candidates.size()));
        p.teleport(t);
        plugin.send(p, "&7Teleported to &f" + t.getName() + "&7.");
    }

    // ------------------------------------------------------------ freeze

    void toggleFreeze(CommandSender by, Player target) {
        if (target.hasPermission("zjsmp.freeze.exempt") && !by.hasPermission("zjsmp.exempt.bypass")) {
            plugin.send(by, "&cYou can't freeze that player.");
            return;
        }
        UUID id = target.getUniqueId();
        String byName = by instanceof Player ? by.getName() : "Console";
        if (frozen.remove(id)) {
            target.clearTitle();
            plugin.send(target, "&aYou have been unfrozen.");
            alert("&f" + byName + " &7unfroze &f" + target.getName() + "&7.");
        } else {
            frozen.add(id);
            target.showTitle(Title.title(
                    plugin.c("&c&lFROZEN"),
                    plugin.c("&7A staff member needs to talk to you. Do not log out."),
                    Title.Times.times(Duration.ZERO, Duration.ofSeconds(60), Duration.ZERO)));
            plugin.send(target, "&cYou have been frozen by staff. Do not log out or you may be banned.");
            alert("&f" + byName + " &7froze &f" + target.getName() + "&7.");
        }
    }

    // ------------------------------------------------------------ alerts & lists

    /** Message to every online player with zjsmp.alerts, plus console. */
    void alert(String message) {
        Component c = plugin.c("{prefix}" + message);
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.hasPermission("zjsmp.alerts")) p.sendMessage(c);
        }
        Bukkit.getConsoleSender().sendMessage(c);
    }

    void staffChat(CommandSender from, String message) {
        String name = from instanceof Player p ? plugin.ranks().format("{rank}&f{name}", p) : "&cConsole";
        Component c = plugin.c("&8[&bStaff&8] " + name + " &8» ")
                .append(Component.text(message, NamedTextColor.AQUA));
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.hasPermission("zjsmp.staffchat")) p.sendMessage(c);
        }
        Bukkit.getConsoleSender().sendMessage(c);
    }

    void sendStaffList(CommandSender viewer) {
        List<Player> list = new ArrayList<>();
        for (Player p : Bukkit.getOnlinePlayers()) {
            boolean isStaff = p.hasPermission("zjsmp.staff") || plugin.ranks().isStaff(p.getUniqueId());
            if (!isStaff) continue;
            if (vanished.contains(p.getUniqueId()) && !viewer.hasPermission("zjsmp.seevanished")) continue;
            list.add(p);
        }
        list.sort(Comparator.comparingInt((Player p) -> plugin.ranks().rankOf(p.getUniqueId()).weight()).reversed());

        plugin.send(viewer, "&fOnline staff &8(&b" + list.size() + "&8)");
        if (list.isEmpty()) {
            viewer.sendMessage(plugin.c(" &7No staff online."));
            return;
        }
        for (Player p : list) {
            String extra = (vanished.contains(p.getUniqueId()) ? " &a(Vanished)" : "")
                    + (staffMode.contains(p.getUniqueId()) ? " &7(Staff Mode)" : "");
            viewer.sendMessage(plugin.c(" &8- " + plugin.ranks().format("{rank}&f{name}", p) + extra));
        }
    }
}

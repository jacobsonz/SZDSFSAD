package com.zjsmp;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

import java.util.HashMap;
import java.util.Map;

/** Marks one of our menus so clicks can be recognised and cancelled. */
final class GuiHolder implements InventoryHolder {

    enum Kind { SHOP_MAIN, SHOP_CATEGORY, AUCTION }

    final Kind kind;
    final String key;
    final int page;
    final Map<Integer, Object> slots = new HashMap<>();
    Inventory inventory;

    GuiHolder(Kind kind, String key, int page) {
        this.kind = kind;
        this.key = key;
        this.page = page;
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }
}

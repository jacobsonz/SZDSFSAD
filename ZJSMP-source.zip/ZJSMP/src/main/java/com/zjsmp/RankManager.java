package com.zjsmp;

import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.permissions.PermissionAttachment;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import java.io.File;
import java.io.IOException;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Built-in rank system (replaces LuckPerms): staff ranks + separate media status. */
final class RankManager {

    record Rank(String id, String display, int weight, boolean staff, String inherits, List<String> permissions) {}

    private final ZJSMP plugin;
    private final File file;
    private final Map<String, Rank> ranks = new LinkedHashMap<>();
    private final Map<UUID, PermissionAttachment> attachments = new HashMap<>();
    private YamlConfiguration data;

    RankManager(ZJSMP plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "players.yml");
        reload();
    }

    void reload() {
        ranks.clear();
        ConfigurationSection sec = plugin.getConfig().getConfigurationSection("ranks");
        if (sec != null) {
            for (String id : sec.getKeys(false)) {
                ConfigurationSection r = sec.getConfigurationSection(id);
                if (r == null) continue;
                String key = id.toLowerCase();
                ranks.put(key, new Rank(key, r.getString("display", ""), r.getInt("weight", 0),
                        r.getBoolean("staff", false), r.getString("inherits"), r.getStringList("permissions")));
            }
        }
        ranks.putIfAbsent("default", new Rank("default", "", 0, false, null, List.of()));
        data = YamlConfiguration.loadConfiguration(file);
    }

    private void save() {
        try {
            plugin.getDataFolder().mkdirs();
            data.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("Could not save players.yml: " + e.getMessage());
        }
    }

    // ------------------------------------------------------------ queries

    Collection<Rank> all() { return ranks.values(); }

    Rank get(String id) { return id == null ? null : ranks.get(id.toLowerCase()); }

    Rank rankOf(UUID id) {
        return ranks.getOrDefault(data.getString("players." + id + ".rank", "default"), ranks.get("default"));
    }

    /** "none", "media" or "plus" */
    String mediaOf(UUID id) { return data.getString("players." + id + ".media", "none"); }

    boolean isStaff(UUID id) { return rankOf(id).staff(); }

    // ------------------------------------------------------------ changes

    void setRank(UUID id, String rank) {
        data.set("players." + id + ".rank", rank.toLowerCase());
        save();
    }

    void setMedia(UUID id, String media) {
        data.set("players." + id + ".media", media.toLowerCase());
        save();
    }

    // ------------------------------------------------------------ formatting

    String mediaBadge(UUID id) {
        String badge = switch (mediaOf(id)) {
            case "plus" -> plugin.getConfig().getString("media.badge-plus", "");
            case "media" -> plugin.getConfig().getString("media.badge", "");
            default -> "";
        };
        return badge.isEmpty() ? "" : badge + " ";
    }

    String rankPrefix(UUID id) {
        String d = rankOf(id).display();
        return d.isEmpty() ? "" : d + " ";
    }

    /** Fills {media}, {rank}, {name}. */
    String format(String template, Player p) {
        return template
                .replace("{media}", mediaBadge(p.getUniqueId()))
                .replace("{rank}", rankPrefix(p.getUniqueId()))
                .replace("{name}", p.getName());
    }

    // ------------------------------------------------------------ applying

    private void collect(Rank r, Set<String> out, Set<String> seen) {
        if (r == null || !seen.add(r.id())) return;
        out.addAll(r.permissions());
        if (r.inherits() != null) collect(ranks.get(r.inherits().toLowerCase()), out, seen);
    }

    /** Gives the player their rank/media permissions and refreshes tab + name tag. */
    void apply(Player p) {
        UUID id = p.getUniqueId();
        PermissionAttachment old = attachments.remove(id);
        if (old != null) {
            try { p.removeAttachment(old); } catch (IllegalArgumentException ignored) { }
        }

        Set<String> perms = new HashSet<>();
        collect(rankOf(id), perms, new HashSet<>());
        String media = mediaOf(id);
        if (!media.equals("none")) perms.add("rank.media");
        if (media.equals("plus")) perms.add("rank.media.plus");

        PermissionAttachment att = p.addAttachment(plugin);
        for (String perm : perms) att.setPermission(perm, true);
        attachments.put(id, att);

        p.recalculatePermissions();
        p.updateCommands();
        updateTab(p);
    }

    void remove(Player p) {
        attachments.remove(p.getUniqueId());
    }

    void updateTab(Player p) {
        String tmpl = plugin.getConfig().getString("tablist.format", "{media}{rank}&f{name}");
        p.playerListName(plugin.c(format(tmpl, p)));
        for (Scoreboard board : plugin.scoreboards().all()) applyTeam(board, p);
    }

    /** Makes sure every online player's rank team exists on this (private) board. */
    void syncBoard(Scoreboard board) {
        for (Player p : Bukkit.getOnlinePlayers()) applyTeam(board, p);
    }

    /** A team per rank keeps the tab list sorted by weight and shows the rank on the name tag. */
    private void applyTeam(Scoreboard board, Player p) {
        Rank r = rankOf(p.getUniqueId());
        int w = Math.max(0, Math.min(999, r.weight()));
        String teamName = "z" + String.format("%03d", 999 - w) + r.id();
        if (teamName.length() > 16) teamName = teamName.substring(0, 16);

        Team current = board.getEntryTeam(p.getName());
        if (current != null && !current.getName().equals(teamName) && current.getName().startsWith("z")) {
            current.removeEntry(p.getName());
        }
        Team team = board.getTeam(teamName);
        if (team == null) team = board.registerNewTeam(teamName);
        team.prefix(plugin.c(r.display().isEmpty() ? "" : r.display() + " "));
        if (!team.hasEntry(p.getName())) team.addEntry(p.getName());
    }
}

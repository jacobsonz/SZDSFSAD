package com.zjsmp;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/** Economy, homes, warps, spawn, tpa, rtp, shop, sell, auction house and scoreboard toggle. */
final class ExtraCommands implements TabExecutor {

    private final ZJSMP plugin;

    ExtraCommands(ZJSMP plugin) {
        this.plugin = plugin;
    }

    private EconomyManager eco() { return plugin.economy(); }
    private TeleportManager tp() { return plugin.teleports(); }

    private boolean playerOnly(CommandSender s) {
        if (s instanceof Player) return false;
        plugin.send(s, "&cPlayers only.");
        return true;
    }

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        switch (cmd.getName().toLowerCase()) {
            case "bal" -> bal(s, a);
            case "pay" -> pay(s, a);
            case "baltop" -> baltop(s);
            case "eco" -> ecoCmd(s, a);
            case "shards" -> shards(s);
            case "sethome" -> sethome(s, a);
            case "home" -> home(s, a);
            case "delhome" -> delhome(s, a);
            case "homes" -> homes(s);
            case "spawn" -> { if (!playerOnly(s)) tp().teleport((Player) s, tp().spawn(), "spawn"); }
            case "setspawn" -> setspawn(s);
            case "tpa" -> tpa(s, a, false);
            case "tpahere" -> tpa(s, a, true);
            case "tpaccept" -> { if (!playerOnly(s)) tp().accept((Player) s); }
            case "tpdeny" -> { if (!playerOnly(s)) tp().deny((Player) s); }
            case "rtp" -> { if (!playerOnly(s)) tp().rtp((Player) s); }
            case "warp" -> warp(s, a);
            case "warps" -> plugin.send(s, "&fWarps: &7" + (tp().warpNames().isEmpty() ? "none" : String.join(", ", tp().warpNames())));
            case "setwarp" -> setwarp(s, a);
            case "delwarp" -> delwarp(s, a);
            case "shop" -> { if (!playerOnly(s)) plugin.shop().openMain((Player) s); }
            case "sell" -> sell(s, a);
            case "sellall" -> { if (!playerOnly(s)) plugin.shop().sellAll((Player) s); }
            case "worth" -> { if (!playerOnly(s)) plugin.shop().worthHand((Player) s); }
            case "ah" -> ah(s, a);
            case "scoreboard" -> {
                if (!playerOnly(s)) {
                    boolean on = plugin.scoreboards().toggle((Player) s);
                    plugin.send(s, on ? "&aScoreboard enabled." : "&cScoreboard disabled.");
                }
            }
            default -> { return false; }
        }
        return true;
    }

    // ------------------------------------------------------------ economy

    private void bal(CommandSender s, String[] a) {
        UUID id;
        String name;
        if (a.length >= 1) {
            id = eco().find(a[0]);
            if (id == null) { plugin.send(s, "&cUnknown player &f" + a[0]); return; }
            name = eco().acc(id).name;
        } else if (s instanceof Player p) {
            id = p.getUniqueId();
            name = p.getName();
        } else {
            plugin.send(s, "&cUsage: /bal <player>");
            return;
        }
        plugin.send(s, "&f" + name + "&7's balance: &a" + EconomyManager.money(eco().balance(id)));
    }

    private void pay(CommandSender s, String[] a) {
        if (playerOnly(s)) return;
        Player p = (Player) s;
        if (a.length < 2) { plugin.send(p, "&cUsage: /pay <player> <amount>"); return; }
        UUID to = eco().find(a[0]);
        if (to == null) { plugin.send(p, "&cUnknown player &f" + a[0]); return; }
        if (to.equals(p.getUniqueId())) { plugin.send(p, "&cYou can't pay yourself."); return; }
        double amt = EconomyManager.parse(a[1]);
        double min = plugin.getConfig().getDouble("economy.min-pay", 1);
        if (Double.isNaN(amt) || amt < min) {
            plugin.send(p, "&cInvalid amount. Minimum is &f" + EconomyManager.money(min) + "&c. You can use 1k, 2.5m, 1b.");
            return;
        }
        if (!eco().take(p.getUniqueId(), amt)) { plugin.send(p, "&cYou don't have enough money."); return; }
        eco().add(to, amt);
        plugin.send(p, "&7You paid &f" + eco().acc(to).name + " &a" + EconomyManager.money(amt) + "&7.");
        Player target = Bukkit.getPlayer(to);
        if (target != null) plugin.send(target, "&f" + p.getName() + " &7paid you &a" + EconomyManager.money(amt) + "&7.");
    }

    private void baltop(CommandSender s) {
        plugin.send(s, "&fRichest players on {server}");
        int i = 1;
        for (EconomyManager.Account acc : eco().top(10)) {
            s.sendMessage(plugin.c(" &8#" + i++ + " &f" + acc.name + " &8- &a" + EconomyManager.money(acc.money)));
        }
    }

    private void shards(CommandSender s) {
        if (playerOnly(s)) return;
        plugin.send(s, "&7You have &d" + eco().acc(((Player) s).getUniqueId()).shards + " shards&7.");
    }

    private void ecoCmd(CommandSender s, String[] a) {
        if (!s.hasPermission("zjsmp.eco")) { plugin.send(s, "&cYou don't have permission to do that."); return; }
        if (a.length >= 1 && a[0].equalsIgnoreCase("shards")) {
            if (a.length < 4) { plugin.send(s, "&cUsage: /eco shards <give|take|set> <player> <amount>"); return; }
            UUID id = eco().find(a[2]);
            if (id == null) { plugin.send(s, "&cUnknown player &f" + a[2]); return; }
            long amt;
            try { amt = Long.parseLong(a[3]); } catch (NumberFormatException e) { plugin.send(s, "&cInvalid number."); return; }
            switch (a[1].toLowerCase()) {
                case "give" -> eco().addShards(id, amt);
                case "take" -> eco().addShards(id, -amt);
                case "set" -> eco().setShards(id, amt);
                default -> { plugin.send(s, "&cUse give, take or set."); return; }
            }
            plugin.send(s, "&7Shards of &f" + a[2] + " &7are now &d" + eco().acc(id).shards + "&7.");
            return;
        }
        if (a.length < 2) { plugin.send(s, "&cUsage: /eco <give|take|set|reset> <player> [amount]"); return; }
        UUID id = eco().find(a[1]);
        if (id == null) { plugin.send(s, "&cUnknown player &f" + a[1]); return; }
        String op = a[0].toLowerCase();
        if (op.equals("reset")) {
            eco().set(id, plugin.getConfig().getDouble("economy.starting-balance", 0));
        } else {
            if (a.length < 3) { plugin.send(s, "&cYou need an amount."); return; }
            double amt = EconomyManager.parse(a[2]);
            if (Double.isNaN(amt) && !(op.equals("set") && a[2].equals("0"))) { plugin.send(s, "&cInvalid amount."); return; }
            if (Double.isNaN(amt)) amt = 0;
            switch (op) {
                case "give" -> eco().add(id, amt);
                case "take" -> eco().add(id, -Math.min(amt, eco().balance(id)));
                case "set" -> eco().set(id, amt);
                default -> { plugin.send(s, "&cUse give, take, set or reset."); return; }
            }
        }
        plugin.send(s, "&f" + a[1] + "&7's balance is now &a" + EconomyManager.money(eco().balance(id)) + "&7.");
    }

    // ------------------------------------------------------------ homes / warps

    private void sethome(CommandSender s, String[] a) {
        if (playerOnly(s)) return;
        Player p = (Player) s;
        String name = a.length > 0 ? a[0] : "home";
        if (!name.matches("[A-Za-z0-9_]{1,16}")) { plugin.send(p, "&cHome names can use letters, numbers and _ (max 16)."); return; }
        if (!tp().setHome(p, name)) {
            plugin.send(p, "&cYou reached your limit of &f" + tp().maxHomes(p) + " &chomes. Use /delhome first.");
            return;
        }
        plugin.send(p, "&7Home &f" + name.toLowerCase() + " &7set.");
    }

    private void home(CommandSender s, String[] a) {
        if (playerOnly(s)) return;
        Player p = (Player) s;
        Set<String> names = tp().homeNames(p.getUniqueId());
        if (names.isEmpty()) { plugin.send(p, "&cYou have no homes. Use &f/sethome&c."); return; }
        String name;
        if (a.length > 0) name = a[0].toLowerCase();
        else if (names.contains("home")) name = "home";
        else if (names.size() == 1) name = names.iterator().next();
        else { plugin.send(p, "&fYour homes: &7" + String.join(", ", names)); return; }
        Location l = tp().home(p.getUniqueId(), name);
        if (l == null) { plugin.send(p, "&cNo home called &f" + name + "&c. Your homes: &7" + String.join(", ", names)); return; }
        tp().teleport(p, l, "home " + name);
    }

    private void delhome(CommandSender s, String[] a) {
        if (playerOnly(s)) return;
        Player p = (Player) s;
        if (a.length < 1) { plugin.send(p, "&cUsage: /delhome <name>"); return; }
        plugin.send(p, tp().delHome(p.getUniqueId(), a[0]) ? "&7Home deleted." : "&cNo home with that name.");
    }

    private void homes(CommandSender s) {
        if (playerOnly(s)) return;
        Player p = (Player) s;
        Set<String> names = tp().homeNames(p.getUniqueId());
        plugin.send(p, "&fHomes &8(&b" + names.size() + "&8/&b" + tp().maxHomes(p) + "&8): &7" + (names.isEmpty() ? "none" : String.join(", ", names)));
    }

    private void setspawn(CommandSender s) {
        if (playerOnly(s)) return;
        if (!s.hasPermission("zjsmp.setspawn")) { plugin.send(s, "&cYou don't have permission to do that."); return; }
        tp().setSpawn(((Player) s).getLocation());
        plugin.send(s, "&7Spawn set to your location.");
    }

    private void warp(CommandSender s, String[] a) {
        if (playerOnly(s)) return;
        Player p = (Player) s;
        if (a.length < 1) { plugin.send(p, "&fWarps: &7" + (tp().warpNames().isEmpty() ? "none" : String.join(", ", tp().warpNames()))); return; }
        Location l = tp().warp(a[0]);
        if (l == null) { plugin.send(p, "&cThat warp doesn't exist."); return; }
        tp().teleport(p, l, "warp " + a[0].toLowerCase());
    }

    private void setwarp(CommandSender s, String[] a) {
        if (playerOnly(s)) return;
        if (!s.hasPermission("zjsmp.warp.manage")) { plugin.send(s, "&cYou don't have permission to do that."); return; }
        if (a.length < 1 || !a[0].matches("[A-Za-z0-9_]{1,16}")) { plugin.send(s, "&cUsage: /setwarp <name>"); return; }
        tp().setWarp(a[0], ((Player) s).getLocation());
        plugin.send(s, "&7Warp &f" + a[0].toLowerCase() + " &7set.");
    }

    private void delwarp(CommandSender s, String[] a) {
        if (!s.hasPermission("zjsmp.warp.manage")) { plugin.send(s, "&cYou don't have permission to do that."); return; }
        if (a.length < 1) { plugin.send(s, "&cUsage: /delwarp <name>"); return; }
        plugin.send(s, tp().delWarp(a[0]) ? "&7Warp deleted." : "&cNo warp with that name.");
    }

    private void tpa(CommandSender s, String[] a, boolean here) {
        if (playerOnly(s)) return;
        Player p = (Player) s;
        if (a.length < 1) { plugin.send(p, "&cUsage: /" + (here ? "tpahere" : "tpa") + " <player>"); return; }
        Player t = Bukkit.getPlayerExact(a[0]);
        if (t == null || (plugin.staff().isVanished(t) && !p.hasPermission("zjsmp.seevanished"))) {
            plugin.send(p, "&cThat player isn't online.");
            return;
        }
        if (t.equals(p)) { plugin.send(p, "&cYou can't teleport to yourself."); return; }
        tp().request(p, t, here);
    }

    // ------------------------------------------------------------ shop / ah

    private void sell(CommandSender s, String[] a) {
        if (playerOnly(s)) return;
        Player p = (Player) s;
        if (a.length > 0 && a[0].equalsIgnoreCase("all")) plugin.shop().sellAll(p);
        else plugin.shop().sellHand(p);
    }

    private void ah(CommandSender s, String[] a) {
        if (playerOnly(s)) return;
        Player p = (Player) s;
        if (a.length == 0) { plugin.auctions().open(p, 0); return; }
        switch (a[0].toLowerCase()) {
            case "sell" -> {
                if (a.length < 2) { plugin.send(p, "&cUsage: /ah sell <price>"); return; }
                double price = EconomyManager.parse(a[1]);
                if (Double.isNaN(price)) { plugin.send(p, "&cInvalid price. You can use 1k, 2.5m, 1b."); return; }
                plugin.auctions().sellHand(p, price);
            }
            case "claim" -> plugin.auctions().claim(p);
            default -> plugin.send(p, "&cUsage: /ah, /ah sell <price>, /ah claim");
        }
    }

    // ------------------------------------------------------------ tab complete

    @Override
    public List<String> onTabComplete(CommandSender s, Command cmd, String label, String[] a) {
        String n = cmd.getName().toLowerCase();
        String last = a[a.length - 1].toLowerCase();
        List<String> out = new ArrayList<>();
        boolean players = switch (n) {
            case "bal", "pay", "tpa", "tpahere" -> a.length == 1;
            case "eco" -> (a.length == 2 && !a[0].equalsIgnoreCase("shards")) || a.length == 3 && a[0].equalsIgnoreCase("shards");
            default -> false;
        };
        if (players) Bukkit.getOnlinePlayers().forEach(p -> out.add(p.getName()));
        else if (n.equals("eco") && a.length == 1) out.addAll(List.of("give", "take", "set", "reset", "shards"));
        else if (n.equals("eco") && a.length == 2 && a[0].equalsIgnoreCase("shards")) out.addAll(List.of("give", "take", "set"));
        else if ((n.equals("home") || n.equals("delhome")) && a.length == 1 && s instanceof Player p) out.addAll(tp().homeNames(p.getUniqueId()));
        else if ((n.equals("warp") || n.equals("delwarp")) && a.length == 1) out.addAll(tp().warpNames());
        else if (n.equals("ah") && a.length == 1) out.addAll(List.of("sell", "claim"));
        else if (n.equals("sell") && a.length == 1) out.add("all");
        out.removeIf(x -> !x.toLowerCase().startsWith(last));
        return out;
    }
}

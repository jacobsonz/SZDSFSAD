package com.zjsmp;

import net.kyori.adventure.text.Component;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Bans, mutes, warns and kicks with history, stored in punishments.yml. */
final class PunishmentManager {

    enum Type { BAN, MUTE, WARN, KICK }

    static final class Punishment {
        final int id;
        final Type type;
        final UUID target;
        final String targetName;
        final String by;
        final String reason;
        final long created;
        final long expires; // -1 = permanent
        boolean active = true;

        Punishment(int id, Type type, UUID target, String targetName, String by, String reason, long created, long expires) {
            this.id = id;
            this.type = type;
            this.target = target;
            this.targetName = targetName;
            this.by = by;
            this.reason = reason;
            this.created = created;
            this.expires = expires;
        }

        boolean isActive() {
            return active && (expires < 0 || expires > System.currentTimeMillis());
        }
    }

    private final ZJSMP plugin;
    private final File file;
    private final List<Punishment> list = new ArrayList<>();
    private int nextId = 1;

    PunishmentManager(ZJSMP plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "punishments.yml");
        load();
    }

    private void load() {
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection s = y.getConfigurationSection("punishments");
        if (s == null) return;
        for (String key : s.getKeys(false)) {
            ConfigurationSection c = s.getConfigurationSection(key);
            if (c == null) continue;
            try {
                Punishment p = new Punishment(Integer.parseInt(key), Type.valueOf(c.getString("type", "WARN")),
                        UUID.fromString(c.getString("target", "")), c.getString("name", "?"),
                        c.getString("by", "?"), c.getString("reason", ""), c.getLong("created"),
                        c.getLong("expires", -1));
                p.active = c.getBoolean("active", true);
                list.add(p);
                nextId = Math.max(nextId, p.id + 1);
            } catch (IllegalArgumentException e) {
                plugin.getLogger().warning("Skipping bad punishment entry " + key);
            }
        }
    }

    private synchronized void save() {
        YamlConfiguration y = new YamlConfiguration();
        for (Punishment p : list) {
            String b = "punishments." + p.id + ".";
            y.set(b + "type", p.type.name());
            y.set(b + "target", p.target.toString());
            y.set(b + "name", p.targetName);
            y.set(b + "by", p.by);
            y.set(b + "reason", p.reason);
            y.set(b + "created", p.created);
            y.set(b + "expires", p.expires);
            y.set(b + "active", p.active);
        }
        try {
            plugin.getDataFolder().mkdirs();
            y.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("Could not save punishments.yml: " + e.getMessage());
        }
    }

    // ------------------------------------------------------------ operations

    synchronized Punishment add(Type type, UUID target, String name, String by, String reason, long durationMs) {
        long now = System.currentTimeMillis();
        Punishment p = new Punishment(nextId++, type, target, name, by, reason, now, durationMs > 0 ? now + durationMs : -1);
        list.add(p);
        save();
        return p;
    }

    synchronized Punishment active(UUID target, Type type) {
        for (Punishment p : list) {
            if (p.type == type && p.target.equals(target) && p.isActive()) return p;
        }
        return null;
    }

    Punishment activeBan(UUID target) { return active(target, Type.BAN); }
    Punishment activeMute(UUID target) { return active(target, Type.MUTE); }

    synchronized boolean revoke(UUID target, Type type) {
        boolean any = false;
        for (Punishment p : list) {
            if (p.type == type && p.target.equals(target) && p.isActive()) {
                p.active = false;
                any = true;
            }
        }
        if (any) save();
        return any;
    }

    /** Newest first. target == null means everyone. */
    synchronized List<Punishment> history(UUID target, int limit) {
        List<Punishment> out = new ArrayList<>();
        for (int i = list.size() - 1; i >= 0 && out.size() < limit; i--) {
            Punishment p = list.get(i);
            if (target == null || p.target.equals(target)) out.add(p);
        }
        return out;
    }

    Component banScreen(Punishment p) {
        String duration = p.expires < 0 ? "Never" : formatDuration(p.expires - System.currentTimeMillis());
        String text = String.join("\n", plugin.getConfig().getStringList("punishments.ban-screen"))
                .replace("{reason}", p.reason)
                .replace("{duration}", duration)
                .replace("{id}", String.valueOf(p.id));
        return plugin.c(text);
    }

    // ------------------------------------------------------------ time helpers

    private static final Pattern PART = Pattern.compile("(\\d+)([smhdw])");

    /** "30s", "15m", "2h", "5d", "1w" or combined like "1d12h". Returns -1 if invalid. */
    static long parseDuration(String s) {
        Matcher m = PART.matcher(s.toLowerCase());
        long total = 0;
        int end = 0;
        while (m.find()) {
            if (m.start() != end) return -1;
            end = m.end();
            long n = Long.parseLong(m.group(1));
            total += n * switch (m.group(2).charAt(0)) {
                case 's' -> 1_000L;
                case 'm' -> 60_000L;
                case 'h' -> 3_600_000L;
                case 'd' -> 86_400_000L;
                default -> 604_800_000L;
            };
        }
        return (end == s.length() && end > 0) ? total : -1;
    }

    static String formatDuration(long ms) {
        if (ms < 1000) return "0s";
        long s = ms / 1000;
        long d = s / 86_400, h = (s % 86_400) / 3600, m = (s % 3600) / 60, sec = s % 60;
        StringBuilder sb = new StringBuilder();
        if (d > 0) sb.append(d).append("d ");
        if (h > 0) sb.append(h).append("h ");
        if (m > 0) sb.append(m).append("m ");
        if (sec > 0 && d == 0) sb.append(sec).append("s");
        return sb.toString().trim();
    }
}

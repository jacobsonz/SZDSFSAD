package com.zjsmp;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.util.List;

public final class ZJSMP extends JavaPlugin {

    private static final LegacyComponentSerializer LEGACY =
            LegacyComponentSerializer.builder().character('&').hexColors().build();

    private static final List<String> COMMANDS = List.of(
            "zjsmp", "media", "ranks", "stafflist", "staffmode", "vanish", "freeze", "staffchat",
            "helpop", "report", "invsee", "ban", "tempban", "unban", "mute", "tempmute", "unmute",
            "warn", "kick", "history");

    private static final List<String> EXTRA_COMMANDS = List.of(
            "bal", "pay", "baltop", "eco", "shards", "sethome", "home", "delhome", "homes", "spawn",
            "setspawn", "tpa", "tpahere", "tpaccept", "tpdeny", "rtp", "warp", "warps", "setwarp",
            "delwarp", "shop", "sell", "sellall", "worth", "ah", "scoreboard");

    private RankManager ranks;
    private StaffManager staff;
    private PunishmentManager punishments;
    private EconomyManager economy;
    private ScoreboardManager scoreboards;
    private TeleportManager teleports;
    private ShopManager shop;
    private AuctionManager auctions;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        for (String res : List.of("shop.yml", "worth.yml")) {
            if (!new File(getDataFolder(), res).exists()) saveResource(res, false);
        }
        economy = new EconomyManager(this);
        scoreboards = new ScoreboardManager(this);
        ranks = new RankManager(this);
        staff = new StaffManager(this);
        punishments = new PunishmentManager(this);
        teleports = new TeleportManager(this);
        shop = new ShopManager(this);
        auctions = new AuctionManager(this);

        getServer().getPluginManager().registerEvents(new Listeners(this), this);
        getServer().getPluginManager().registerEvents(new ExtraListeners(this), this);

        Commands handler = new Commands(this);
        for (String name : COMMANDS) {
            PluginCommand pc = getCommand(name);
            if (pc != null) {
                pc.setExecutor(handler);
                pc.setTabCompleter(handler);
            }
        }

        ExtraCommands extra = new ExtraCommands(this);
        for (String name : EXTRA_COMMANDS) {
            PluginCommand pc = getCommand(name);
            if (pc != null) {
                pc.setExecutor(extra);
                pc.setTabCompleter(extra);
            }
        }

        // Handles /reload and late loading.
        for (Player p : getServer().getOnlinePlayers()) {
            economy.onJoin(p);
            ranks.apply(p);
            staff.onJoin(p);
            scoreboards.show(p);
        }
        staff.refreshVisibility();

        staff.start();
        scoreboards.start();
        getServer().getScheduler().runTaskTimer(this, economy::tick, 20L, 20L);
        getServer().getScheduler().runTaskTimer(this, economy::saveIfDirty, 1200L, 1200L);
        getServer().getScheduler().runTaskTimer(this, auctions::expireOld, 1200L, 1200L);
        getServer().getScheduler().runTaskTimer(this, this::refreshTablist, 20L, 100L);
        getLogger().info(serverName() + " core enabled.");
    }

    @Override
    public void onDisable() {
        if (scoreboards != null) scoreboards.removeAll();
        if (economy != null) economy.shutdown();
        if (auctions != null) auctions.save();
    }

    public void reloadAll() {
        reloadConfig();
        shop.reload();
        scoreboards.start();
        ranks.reload();
        for (Player p : getServer().getOnlinePlayers()) {
            ranks.apply(p);
        }
        staff.refreshVisibility();
    }

    private void refreshTablist() {
        if (!getConfig().getBoolean("tablist.enabled", true)) return;
        String online = String.valueOf(getServer().getOnlinePlayers().size() - staff.vanishedCount());
        Component header = c(String.join("\n", getConfig().getStringList("tablist.header")).replace("{online}", online));
        Component footer = c(String.join("\n", getConfig().getStringList("tablist.footer")).replace("{online}", online));
        for (Player p : getServer().getOnlinePlayers()) {
            p.sendPlayerListHeaderAndFooter(header, footer);
        }
    }

    // ------------------------------------------------------------ helpers

    public String serverName() {
        return getConfig().getString("server-name", "ZJSMP");
    }

    /** Replaces {prefix} and {server}. */
    public String fmt(String s) {
        return s.replace("{prefix}", getConfig().getString("prefix", "&b&l{server} &8» &7"))
                .replace("{server}", serverName());
    }

    /** Legacy (&) + hex (&#RRGGBB) string to Component. */
    public Component c(String s) {
        return LEGACY.deserialize(fmt(s));
    }

    public void send(CommandSender to, String message) {
        to.sendMessage(c("{prefix}" + message));
    }

    public RankManager ranks() { return ranks; }
    public StaffManager staff() { return staff; }
    public PunishmentManager punishments() { return punishments; }
    public EconomyManager economy() { return economy; }
    public ScoreboardManager scoreboards() { return scoreboards; }
    public TeleportManager teleports() { return teleports; }
    public ShopManager shop() { return shop; }
    public AuctionManager auctions() { return auctions; }
}

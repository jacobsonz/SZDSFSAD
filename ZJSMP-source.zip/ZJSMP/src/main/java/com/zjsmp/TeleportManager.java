package com.zjsmp;

import net.kyori.adventure.text.event.ClickEvent;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.WorldBorder;
import org.bukkit.block.Block;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/** Homes, warps, spawn, /tpa and /rtp, all with a stand-still warm-up. */
final class TeleportManager {

    private record Request(UUID from, boolean here, long expires) { }

    private final ZJSMP plugin;
    private final File homesFile;
    private final File warpsFile;
    private final YamlConfiguration homes;
    private final YamlConfiguration warps;
    private final Map<UUID, Request> requests = new HashMap<>();
    private final Set<UUID> pending = new HashSet<>();

    TeleportManager(ZJSMP plugin) {
        this.plugin = plugin;
        this.homesFile = new File(plugin.getDataFolder(), "homes.yml");
        this.warpsFile = new File(plugin.getDataFolder(), "warps.yml");
        this.homes = YamlConfiguration.loadConfiguration(homesFile);
        this.warps = YamlConfiguration.loadConfiguration(warpsFile);
    }

    private void save(YamlConfiguration y, File f) {
        try {
            plugin.getDataFolder().mkdirs();
            y.save(f);
        } catch (IOException e) {
            plugin.getLogger().warning("Could not save " + f.getName() + ": " + e.getMessage());
        }
    }

    // ------------------------------------------------------------ warm-up teleport

    void teleport(Player p, Location dest, String label) {
        int delay = plugin.getConfig().getInt("teleport.delay-seconds", 3);
        if (delay <= 0 || p.hasPermission("zjsmp.teleport.bypass")) {
            p.teleportAsync(dest);
            plugin.send(p, "&7Teleported to &f" + label + "&7.");
            return;
        }
        if (!pending.add(p.getUniqueId())) {
            plugin.send(p, "&cYou are already teleporting.");
            return;
        }
        Location start = p.getLocation();
        plugin.send(p, "&7Teleporting to &f" + label + " &7in &f" + delay + "s&7. Don't move!");
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            pending.remove(p.getUniqueId());
            if (!p.isOnline()) return;
            Location now = p.getLocation();
            if (now.getWorld() != start.getWorld() || now.distanceSquared(start) > 2.0) {
                plugin.send(p, "&cTeleport cancelled because you moved.");
                return;
            }
            p.teleportAsync(dest);
            plugin.send(p, "&7Teleported to &f" + label + "&7.");
        }, delay * 20L);
    }

    // ------------------------------------------------------------ homes

    int maxHomes(Player p) {
        var c = plugin.getConfig();
        int max = c.getInt("homes.limits.default", 3);
        if (p.hasPermission("zjsmp.staff")) max = Math.max(max, c.getInt("homes.limits.staff", 10));
        if (p.hasPermission("rank.media.plus")) max = Math.max(max, c.getInt("homes.limits.plus", 7));
        else if (p.hasPermission("rank.media")) max = Math.max(max, c.getInt("homes.limits.media", 5));
        return max;
    }

    Set<String> homeNames(UUID id) {
        ConfigurationSection s = homes.getConfigurationSection("homes." + id);
        return s == null ? new TreeSet<>() : new TreeSet<>(s.getKeys(false));
    }

    Location home(UUID id, String name) {
        Location l = homes.getLocation("homes." + id + "." + name.toLowerCase());
        return (l == null || l.getWorld() == null) ? null : l;
    }

    /** false = at the home limit. */
    boolean setHome(Player p, String name) {
        name = name.toLowerCase();
        Set<String> names = homeNames(p.getUniqueId());
        if (!names.contains(name) && names.size() >= maxHomes(p)) return false;
        homes.set("homes." + p.getUniqueId() + "." + name, p.getLocation());
        save(homes, homesFile);
        return true;
    }

    boolean delHome(UUID id, String name) {
        if (!homeNames(id).contains(name.toLowerCase())) return false;
        homes.set("homes." + id + "." + name.toLowerCase(), null);
        save(homes, homesFile);
        return true;
    }

    // ------------------------------------------------------------ warps & spawn

    Set<String> warpNames() {
        ConfigurationSection s = warps.getConfigurationSection("warps");
        return s == null ? new TreeSet<>() : new TreeSet<>(s.getKeys(false));
    }

    Location warp(String name) {
        Location l = warps.getLocation("warps." + name.toLowerCase());
        return (l == null || l.getWorld() == null) ? null : l;
    }

    void setWarp(String name, Location l) {
        warps.set("warps." + name.toLowerCase(), l);
        save(warps, warpsFile);
    }

    boolean delWarp(String name) {
        if (warp(name) == null) return false;
        warps.set("warps." + name.toLowerCase(), null);
        save(warps, warpsFile);
        return true;
    }

    Location spawn() {
        Location l = warps.getLocation("spawn");
        if (l != null && l.getWorld() != null) return l;
        return Bukkit.getWorlds().get(0).getSpawnLocation();
    }

    void setSpawn(Location l) {
        warps.set("spawn", l);
        save(warps, warpsFile);
    }

    // ------------------------------------------------------------ tpa

    void request(Player from, Player to, boolean here) {
        requests.put(to.getUniqueId(), new Request(from.getUniqueId(), here, System.currentTimeMillis() + 60_000L));
        plugin.send(from, "&7Teleport request sent to &f" + to.getName() + "&7. It expires in 60 seconds.");
        plugin.send(to, "&f" + from.getName() + " &7wants " + (here ? "you to teleport to them." : "to teleport to you."));
        to.sendMessage(plugin.c("  &a[ACCEPT]").clickEvent(ClickEvent.runCommand("/tpaccept"))
                .append(plugin.c("  &c[DENY]").clickEvent(ClickEvent.runCommand("/tpdeny"))));
    }

    void accept(Player target) {
        Request r = requests.remove(target.getUniqueId());
        if (r == null || r.expires() < System.currentTimeMillis()) {
            plugin.send(target, "&cYou have no pending teleport requests.");
            return;
        }
        Player from = Bukkit.getPlayer(r.from());
        if (from == null) {
            plugin.send(target, "&cThat player is no longer online.");
            return;
        }
        plugin.send(target, "&aTeleport request accepted.");
        plugin.send(from, "&f" + target.getName() + " &aaccepted your request.");
        if (r.here()) teleport(target, from.getLocation(), from.getName());
        else teleport(from, target.getLocation(), target.getName());
    }

    void deny(Player target) {
        Request r = requests.remove(target.getUniqueId());
        if (r == null) {
            plugin.send(target, "&cYou have no pending teleport requests.");
            return;
        }
        plugin.send(target, "&cTeleport request denied.");
        Player from = Bukkit.getPlayer(r.from());
        if (from != null) plugin.send(from, "&f" + target.getName() + " &cdenied your request.");
    }

    // ------------------------------------------------------------ rtp

    void rtp(Player p) {
        World w = Bukkit.getWorld(plugin.getConfig().getString("rtp.world", "world"));
        if (w == null) w = p.getWorld();
        if (w.getEnvironment() != World.Environment.NORMAL) {
            plugin.send(p, "&cRandom teleport only works in the overworld.");
            return;
        }
        plugin.send(p, "&7Finding a safe spot...");
        attempt(p, w, 0);
    }

    private void attempt(Player p, World w, int tries) {
        if (!p.isOnline()) return;
        if (tries >= 10) {
            plugin.send(p, "&cCouldn't find a safe location, try again.");
            return;
        }
        int min = plugin.getConfig().getInt("rtp.min-radius", 500);
        int max = plugin.getConfig().getInt("rtp.max-radius", 5000);
        WorldBorder border = w.getWorldBorder();
        double half = border.getSize() / 2.0 - 16;
        if (half > 0) max = (int) Math.min(max, half);
        if (max <= min) min = 0;
        double angle = ThreadLocalRandom.current().nextDouble(Math.PI * 2);
        double r = min + ThreadLocalRandom.current().nextDouble() * Math.max(1, max - min);
        final int x = (int) (border.getCenter().getX() + Math.cos(angle) * r);
        final int z = (int) (border.getCenter().getZ() + Math.sin(angle) * r);

        w.getChunkAtAsync(x >> 4, z >> 4).thenAccept(chunk -> Bukkit.getScheduler().runTask(plugin, () -> {
            int y = w.getHighestBlockYAt(x, z);
            Block ground = w.getBlockAt(x, y, z);
            Material m = ground.getType();
            if (!m.isSolid() || m == Material.MAGMA_BLOCK || m == Material.CACTUS || m == Material.POWDER_SNOW) {
                attempt(p, w, tries + 1);
                return;
            }
            teleport(p, new Location(w, x + 0.5, y + 1, z + 0.5, p.getLocation().getYaw(), p.getLocation().getPitch()),
                    "a random location");
        }));
    }
}

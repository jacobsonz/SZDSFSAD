package com.zjsmp;

import org.bukkit.entity.Player;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Built-in replacement for PlaceholderAPI. Supports %economy_money%, %economy_nicestMoney%,
 * %economy_shards%, %economy_kills%, %economy_deaths%, %economy_playtime%, %economy_ping%,
 * %economy_keyall_countdown%, %economy_username%, %player_name%, %player_ping%,
 * %zjsmp_rank%, %zjsmp_media%, %server_online%, %server_name%.
 */
final class Placeholders {

    private static final Pattern TOKEN = Pattern.compile("%([a-zA-Z0-9_]+)%");
    private static final Map<String, Function<Player, String>> CUSTOM = new ConcurrentHashMap<>();

    private Placeholders() { }

    /** Other code can add its own placeholder: key without percent signs, lower case. */
    static void register(String key, Function<Player, String> fn) {
        CUSTOM.put(key.toLowerCase(), fn);
    }

    static String apply(ZJSMP plugin, Player p, String text) {
        if (text == null || text.indexOf('%') < 0) return text;
        Matcher m = TOKEN.matcher(text);
        StringBuilder sb = new StringBuilder();
        while (m.find()) {
            String val = resolve(plugin, p, m.group(1).toLowerCase());
            m.appendReplacement(sb, Matcher.quoteReplacement(val != null ? val : m.group()));
        }
        m.appendTail(sb);
        return sb.toString();
    }

    private static String resolve(ZJSMP plugin, Player p, String key) {
        if (p == null) return null;
        EconomyManager eco = plugin.economy();
        var id = p.getUniqueId();
        return switch (key) {
            case "player_name", "economy_username" -> p.getName();
            case "player_ping", "economy_ping" -> String.valueOf(p.getPing());
            case "economy_money" -> String.format(java.util.Locale.US, "%,.2f", eco.balance(id));
            case "economy_nicestmoney" -> EconomyManager.nice(eco.balance(id));
            case "economy_shards" -> String.valueOf(eco.acc(id).shards);
            case "economy_kills" -> String.valueOf(eco.acc(id).kills);
            case "economy_deaths" -> String.valueOf(eco.acc(id).deaths);
            case "economy_playtime" -> EconomyManager.time(eco.playtimeSeconds(id));
            case "economy_keyall_countdown" -> eco.keyallCountdown();
            case "zjsmp_rank" -> plugin.ranks().rankOf(id).display();
            case "zjsmp_media" -> plugin.ranks().mediaBadge(id).trim();
            case "server_online" -> String.valueOf(plugin.getServer().getOnlinePlayers().size() - plugin.staff().vanishedCount());
            case "server_name" -> plugin.serverName();
            default -> {
                Function<Player, String> fn = CUSTOM.get(key);
                yield fn == null ? null : fn.apply(p);
            }
        };
    }
}

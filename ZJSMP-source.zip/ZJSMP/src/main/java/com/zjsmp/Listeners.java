package com.zjsmp;

import io.papermc.paper.chat.ChatRenderer;
import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.EntityTargetLivingEntityEvent;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.EquipmentSlot;

import java.util.List;

final class Listeners implements Listener {

    private final ZJSMP plugin;

    Listeners(ZJSMP plugin) {
        this.plugin = plugin;
    }

    private RankManager ranks() { return plugin.ranks(); }
    private StaffManager staff() { return plugin.staff(); }
    private PunishmentManager pun() { return plugin.punishments(); }

    // ------------------------------------------------------------ join / quit / login

    @EventHandler(priority = EventPriority.HIGH)
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        plugin.economy().onJoin(p);
        ranks().apply(p);
        staff().onJoin(p);
        plugin.scoreboards().show(p);
        if (staff().isVanished(p)) {
            e.joinMessage(null);
            return;
        }
        String msg = plugin.getConfig().getString("join-message", "");
        if (!msg.isEmpty()) e.joinMessage(plugin.c(ranks().format(msg, p)));
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        if (staff().isFrozen(p)) staff().alert("&c" + p.getName() + " &7logged out while frozen!");
        if (staff().isVanished(p)) {
            e.quitMessage(null);
        } else {
            String msg = plugin.getConfig().getString("quit-message", "");
            if (!msg.isEmpty()) e.quitMessage(plugin.c(ranks().format(msg, p)));
        }
        staff().onQuit(p);
        ranks().remove(p);
        plugin.economy().onQuit(p);
        plugin.scoreboards().remove(p);
    }

    @EventHandler
    public void onPreLogin(AsyncPlayerPreLoginEvent e) {
        PunishmentManager.Punishment ban = pun().activeBan(e.getUniqueId());
        if (ban != null) {
            e.disallow(AsyncPlayerPreLoginEvent.Result.KICK_BANNED, pun().banScreen(ban));
        }
    }

    // ------------------------------------------------------------ chat

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onChat(AsyncChatEvent e) {
        Player p = e.getPlayer();

        PunishmentManager.Punishment mute = pun().activeMute(p.getUniqueId());
        if (mute != null) {
            e.setCancelled(true);
            String left = mute.expires < 0 ? "permanently"
                    : "for another " + PunishmentManager.formatDuration(mute.expires - System.currentTimeMillis());
            plugin.send(p, "&cYou are muted " + left + ". &7Reason: &f" + mute.reason);
            return;
        }

        if (staff().staffChatToggle.contains(p.getUniqueId()) && p.hasPermission("zjsmp.staffchat")) {
            e.setCancelled(true);
            String plain = PlainTextComponentSerializer.plainText().serialize(e.message());
            plugin.getServer().getScheduler().runTask(plugin, () -> staff().staffChat(p, plain));
            return;
        }

        String tmpl = plugin.getConfig().getString("chat.format", "{media}{rank}&f{name} &8» &f");
        Component prefix = plugin.c(ranks().format(tmpl, p));
        e.renderer(ChatRenderer.viewerUnaware((source, name, message) -> prefix.append(message)));
    }

    // ------------------------------------------------------------ freeze

    @EventHandler(ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        if (!staff().isFrozen(e.getPlayer())) return;
        Location from = e.getFrom();
        Location to = e.getTo();
        if (to == null) return;
        if (from.getX() != to.getX() || from.getY() != to.getY() || from.getZ() != to.getZ()) {
            e.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        if (!staff().isFrozen(e.getPlayer())) return;
        String label = e.getMessage().substring(1).split(" ")[0].toLowerCase();
        int colon = label.indexOf(':');
        if (colon >= 0) label = label.substring(colon + 1);
        List<String> allowed = plugin.getConfig().getStringList("freeze.allowed-commands");
        if (!allowed.contains(label)) {
            e.setCancelled(true);
            plugin.send(e.getPlayer(), "&cYou can't use commands while frozen.");
        }
    }

    // ------------------------------------------------------------ staff mode tools

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        Player p = e.getPlayer();
        String id = staff().toolId(e.getItem());
        if (id == null || !staff().inStaffMode(p)) return;
        e.setCancelled(true);
        if (e.getAction() == Action.PHYSICAL) return;
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;

        switch (id) {
            case "vanish" -> {
                if (p.hasPermission("zjsmp.vanish")) staff().toggleVanish(p);
            }
            case "stafflist" -> staff().sendStaffList(p);
            case "betterview" -> staff().toggleBetterView(p);
            case "randomtp" -> staff().randomTp(p);
            case "freeze" -> plugin.send(p, "&7Right-click a player to freeze them.");
            default -> { }
        }
    }

    @EventHandler
    public void onInteractEntity(PlayerInteractEntityEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        Player p = e.getPlayer();
        if (!staff().inStaffMode(p)) return;
        if (!"freeze".equals(staff().toolId(p.getInventory().getItemInMainHand()))) return;
        e.setCancelled(true);
        if (e.getRightClicked() instanceof Player target && p.hasPermission("zjsmp.freeze")) {
            staff().toggleFreeze(p, target);
        }
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p) || !staff().inStaffMode(p)) return;
        boolean tool = staff().toolId(e.getCurrentItem()) != null || staff().toolId(e.getCursor()) != null;
        if (!tool && e.getClick() == ClickType.NUMBER_KEY && e.getHotbarButton() >= 0) {
            tool = staff().toolId(p.getInventory().getItem(e.getHotbarButton())) != null;
        }
        if (!tool && e.getClick() == ClickType.SWAP_OFFHAND) {
            tool = staff().toolId(p.getInventory().getItemInOffHand()) != null;
        }
        if (tool) e.setCancelled(true);
    }

    @EventHandler
    public void onDrop(PlayerDropItemEvent e) {
        if (staff().inStaffMode(e.getPlayer()) && staff().toolId(e.getItemDrop().getItemStack()) != null) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onSwap(PlayerSwapHandItemsEvent e) {
        if (staff().inStaffMode(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler
    public void onPickup(EntityPickupItemEvent e) {
        if (e.getEntity() instanceof Player p && staff().inStaffMode(p) && !p.hasPermission("zjsmp.admin")) {
            e.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        Player p = e.getPlayer();
        if (staff().inStaffMode(p) && !p.hasPermission("zjsmp.admin")) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        Player p = e.getPlayer();
        if (staff().inStaffMode(p) && !p.hasPermission("zjsmp.admin")) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent e) {
        if (e.getDamager() instanceof Player p && staff().inStaffMode(p) && !p.hasPermission("zjsmp.admin")) {
            e.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onTarget(EntityTargetLivingEntityEvent e) {
        if (e.getTarget() instanceof Player p && staff().isVanished(p)) e.setCancelled(true);
    }
}

package com.zjsmp;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Player auction house: /ah, /ah sell <price>, /ah claim. Stored in auction.yml. */
final class AuctionManager {

    static final class Listing {
        int id;
        UUID seller;
        String sellerName;
        double price;
        long created;
        long expires;
        ItemStack item;
    }

    private static final int PAGE_SIZE = 45;

    private final ZJSMP plugin;
    private final File file;
    private final List<Listing> listings = new ArrayList<>();
    private final Map<UUID, List<ItemStack>> claims = new HashMap<>();
    private int nextId = 1;

    AuctionManager(ZJSMP plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "auction.yml");
        load();
    }

    // ------------------------------------------------------------ storage

    private static String encode(ItemStack item) {
        return Base64.getEncoder().encodeToString(item.serializeAsBytes());
    }

    private static ItemStack decode(String s) {
        return ItemStack.deserializeBytes(Base64.getDecoder().decode(s));
    }

    private void load() {
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection ls = y.getConfigurationSection("listings");
        if (ls != null) {
            for (String key : ls.getKeys(false)) {
                try {
                    ConfigurationSection c = ls.getConfigurationSection(key);
                    if (c == null) continue;
                    Listing l = new Listing();
                    l.id = Integer.parseInt(key);
                    l.seller = UUID.fromString(c.getString("seller", ""));
                    l.sellerName = c.getString("name", "?");
                    l.price = c.getDouble("price");
                    l.created = c.getLong("created");
                    l.expires = c.getLong("expires");
                    l.item = decode(c.getString("item", ""));
                    listings.add(l);
                    nextId = Math.max(nextId, l.id + 1);
                } catch (RuntimeException e) {
                    plugin.getLogger().warning("Skipping bad auction listing " + key);
                }
            }
        }
        ConfigurationSection cs = y.getConfigurationSection("claims");
        if (cs != null) {
            for (String key : cs.getKeys(false)) {
                try {
                    UUID id = UUID.fromString(key);
                    List<ItemStack> items = new ArrayList<>();
                    for (String enc : cs.getStringList(key)) items.add(decode(enc));
                    claims.put(id, items);
                } catch (RuntimeException e) {
                    plugin.getLogger().warning("Skipping bad auction claim " + key);
                }
            }
        }
    }

    synchronized void save() {
        YamlConfiguration y = new YamlConfiguration();
        for (Listing l : listings) {
            String b = "listings." + l.id + ".";
            y.set(b + "seller", l.seller.toString());
            y.set(b + "name", l.sellerName);
            y.set(b + "price", l.price);
            y.set(b + "created", l.created);
            y.set(b + "expires", l.expires);
            y.set(b + "item", encode(l.item));
        }
        for (Map.Entry<UUID, List<ItemStack>> e : claims.entrySet()) {
            if (e.getValue().isEmpty()) continue;
            y.set("claims." + e.getKey(), e.getValue().stream().map(AuctionManager::encode).toList());
        }
        try {
            plugin.getDataFolder().mkdirs();
            y.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("Could not save auction.yml: " + e.getMessage());
        }
    }

    // ------------------------------------------------------------ logic

    /** Moves expired listings into their owner's claim box. */
    void expireOld() {
        long now = System.currentTimeMillis();
        boolean changed = false;
        for (Iterator<Listing> it = listings.iterator(); it.hasNext(); ) {
            Listing l = it.next();
            if (l.expires <= now) {
                claims.computeIfAbsent(l.seller, k -> new ArrayList<>()).add(l.item);
                it.remove();
                changed = true;
            }
        }
        if (changed) save();
    }

    private Listing get(int id) {
        for (Listing l : listings) if (l.id == id) return l;
        return null;
    }

    private int countOf(UUID seller) {
        int n = 0;
        for (Listing l : listings) if (l.seller.equals(seller)) n++;
        return n;
    }

    void sellHand(Player p, double price) {
        var cfg = plugin.getConfig();
        double min = cfg.getDouble("auction.min-price", 1);
        double max = cfg.getDouble("auction.max-price", 1_000_000_000_000.0);
        if (price < min || price > max) {
            plugin.send(p, "&cPrice must be between &f" + EconomyManager.money(min) + " &cand &f" + EconomyManager.money(max) + "&c.");
            return;
        }
        ItemStack hand = p.getInventory().getItemInMainHand();
        if (hand.getType().isAir()) {
            plugin.send(p, "&cHold the item you want to sell.");
            return;
        }
        if (countOf(p.getUniqueId()) >= cfg.getInt("auction.max-listings", 10)) {
            plugin.send(p, "&cYou already have the maximum number of listings.");
            return;
        }
        Listing l = new Listing();
        l.id = nextId++;
        l.seller = p.getUniqueId();
        l.sellerName = p.getName();
        l.price = price;
        l.created = System.currentTimeMillis();
        l.expires = l.created + cfg.getLong("auction.duration-hours", 48) * 3_600_000L;
        l.item = hand.clone();
        listings.add(l);
        p.getInventory().setItemInMainHand(null);
        save();
        plugin.send(p, "&7Listed &f" + l.item.getAmount() + "x " + l.item.getType().name().toLowerCase().replace('_', ' ')
                + " &7for &a" + EconomyManager.money(price) + "&7.");
    }

    void claim(Player p) {
        List<ItemStack> items = claims.get(p.getUniqueId());
        if (items == null || items.isEmpty()) {
            plugin.send(p, "&cYou have nothing to claim.");
            return;
        }
        int n = items.size();
        for (ItemStack it : items) ShopManager.give(p, it);
        claims.remove(p.getUniqueId());
        save();
        plugin.send(p, "&aClaimed &f" + n + " &aexpired item stack(s).");
    }

    // ------------------------------------------------------------ menu

    private Component line(String s) {
        return plugin.c(s).decoration(TextDecoration.ITALIC, false);
    }

    void open(Player p, int page) {
        expireOld();
        List<Listing> sorted = new ArrayList<>(listings);
        sorted.sort(Comparator.comparingLong((Listing l) -> l.created).reversed());
        int pages = Math.max(1, (sorted.size() + PAGE_SIZE - 1) / PAGE_SIZE);
        page = Math.max(0, Math.min(page, pages - 1));

        GuiHolder h = new GuiHolder(GuiHolder.Kind.AUCTION, "", page);
        h.inventory = Bukkit.createInventory(h, 54, plugin.c("&8{server} Auction House"));

        long now = System.currentTimeMillis();
        int start = page * PAGE_SIZE;
        for (int i = 0; i < PAGE_SIZE && start + i < sorted.size(); i++) {
            Listing l = sorted.get(start + i);
            ItemStack display = l.item.clone();
            ItemMeta meta = display.getItemMeta();
            List<Component> lore = meta.lore() == null ? new ArrayList<>() : new ArrayList<>(meta.lore());
            lore.add(Component.empty());
            lore.add(line("&7Price: &a" + EconomyManager.money(l.price)));
            lore.add(line("&7Seller: &f" + l.sellerName));
            lore.add(line("&7Expires in: &f" + EconomyManager.time(Math.max(0, (l.expires - now) / 1000))));
            lore.add(line(l.seller.equals(p.getUniqueId()) ? "&cClick to cancel your listing" : "&eClick to buy"));
            meta.lore(lore);
            display.setItemMeta(meta);
            h.inventory.setItem(i, display);
            h.slots.put(i, l.id);
        }

        ShopManager shop = plugin.shop();
        if (page > 0) h.inventory.setItem(45, shop.named(Material.ARROW, "&ePrevious page"));
        h.inventory.setItem(49, shop.named(Material.PAPER, "&fPage " + (page + 1) + "/" + pages,
                "&7Use &f/ah sell <price> &7to list", "&7the item in your hand.", "&7Expired items: &f/ah claim"));
        if (page < pages - 1) h.inventory.setItem(53, shop.named(Material.ARROW, "&eNext page"));
        p.openInventory(h.inventory);
    }

    void handleClick(Player p, GuiHolder h, InventoryClickEvent e) {
        int slot = e.getSlot();
        if (slot == 45 && h.page > 0) { open(p, h.page - 1); return; }
        if (slot == 53) { open(p, h.page + 1); return; }
        if (!(h.slots.get(slot) instanceof Integer id)) return;

        Listing l = get(id);
        if (l == null) {
            plugin.send(p, "&cThat listing is no longer available.");
            open(p, h.page);
            return;
        }
        if (l.seller.equals(p.getUniqueId())) {
            listings.remove(l);
            save();
            ShopManager.give(p, l.item);
            plugin.send(p, "&7Your listing was cancelled and the item returned.");
            open(p, h.page);
            return;
        }
        EconomyManager eco = plugin.economy();
        if (!eco.take(p.getUniqueId(), l.price)) {
            plugin.send(p, "&cYou need &f" + EconomyManager.money(l.price) + " &cto buy that.");
            return;
        }
        double tax = plugin.getConfig().getDouble("auction.tax-percent", 5);
        eco.add(l.seller, l.price * (1 - tax / 100.0));
        listings.remove(l);
        save();
        ShopManager.give(p, l.item.clone());
        plugin.send(p, "&7You bought &f" + l.item.getAmount() + "x " + l.item.getType().name().toLowerCase().replace('_', ' ')
                + " &7for &a" + EconomyManager.money(l.price) + "&7.");
        Player seller = Bukkit.getPlayer(l.seller);
        if (seller != null) {
            plugin.send(seller, "&f" + p.getName() + " &7bought your item for &a" + EconomyManager.money(l.price)
                    + " &7(&c" + tax + "% &7tax).");
        }
        open(p, h.page);
    }
}

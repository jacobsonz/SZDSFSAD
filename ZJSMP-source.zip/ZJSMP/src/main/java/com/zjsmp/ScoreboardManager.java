package com.zjsmp;

import io.papermc.paper.scoreboard.numbers.NumberFormat;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.scoreboard.Criteria;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Animated sidebar scoreboard (one private board per player). */
final class ScoreboardManager {

    private static final int MAX_LINES = 15;

    private static final class Board {
        final Scoreboard sb;
        final Objective obj;

        Board(Scoreboard sb, Objective obj) {
            this.sb = sb;
            this.obj = obj;
        }
    }

    private final ZJSMP plugin;
    private final Map<UUID, Board> boards = new HashMap<>();
    private final Set<UUID> disabled = new HashSet<>();
    private BukkitTask task;
    private int frame;

    ScoreboardManager(ZJSMP plugin) {
        this.plugin = plugin;
    }

    /** The main board plus every private board, so rank name tags work on all of them. */
    Collection<Scoreboard> all() {
        List<Scoreboard> list = new ArrayList<>();
        list.add(Bukkit.getScoreboardManager().getMainScoreboard());
        for (Board b : boards.values()) list.add(b.sb);
        return list;
    }

    void start() {
        if (task != null) task.cancel();
        long period = Math.max(2, plugin.getConfig().getInt("scoreboard.update-ticks", 20));
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 20L, period);
    }

    private void tick() {
        frame++;
        boolean enabled = plugin.getConfig().getBoolean("scoreboard.enabled", true);
        for (Player p : Bukkit.getOnlinePlayers()) {
            UUID id = p.getUniqueId();
            if (!enabled || disabled.contains(id)) {
                if (boards.containsKey(id)) hide(p);
                continue;
            }
            Board b = boards.get(id);
            if (b == null) show(p);
            else render(p, b);
        }
    }

    void show(Player p) {
        if (!plugin.getConfig().getBoolean("scoreboard.enabled", true) || disabled.contains(p.getUniqueId())) return;
        Scoreboard sb = Bukkit.getScoreboardManager().getNewScoreboard();
        Objective obj = sb.registerNewObjective("zjsmp", Criteria.DUMMY, Component.text(plugin.serverName()));
        obj.setDisplaySlot(DisplaySlot.SIDEBAR);
        obj.numberFormat(NumberFormat.blank());
        Board b = new Board(sb, obj);
        boards.put(p.getUniqueId(), b);
        plugin.ranks().syncBoard(sb);
        p.setScoreboard(sb);
        render(p, b);
    }

    void hide(Player p) {
        boards.remove(p.getUniqueId());
        p.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());
    }

    /** Player left: just forget their board. */
    void remove(Player p) {
        boards.remove(p.getUniqueId());
    }

    void removeAll() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (boards.containsKey(p.getUniqueId())) hide(p);
        }
        boards.clear();
    }

    /** Returns true if the scoreboard is now ON. */
    boolean toggle(Player p) {
        UUID id = p.getUniqueId();
        if (disabled.remove(id)) {
            show(p);
            return true;
        }
        disabled.add(id);
        hide(p);
        return false;
    }

    private void render(Player p, Board b) {
        List<String> titles = plugin.getConfig().getStringList("scoreboard.title");
        String title = titles.isEmpty() ? "&b&l{server}" : titles.get(frame % titles.size());
        b.obj.displayName(plugin.c(title));

        List<String> lines = plugin.getConfig().getStringList("scoreboard.lines");
        int count = Math.min(lines.size(), MAX_LINES);
        for (int i = 0; i < MAX_LINES; i++) {
            String entry = "\u00a7" + Integer.toHexString(i) + "\u00a7r";
            if (i >= count) {
                b.sb.resetScores(entry);
                continue;
            }
            Team t = b.sb.getTeam("line" + i);
            if (t == null) {
                t = b.sb.registerNewTeam("line" + i);
                t.addEntry(entry);
            }
            t.prefix(plugin.c(Placeholders.apply(plugin, p, lines.get(i))));
            b.obj.getScore(entry).setScore(count - i);
        }
    }
}

package com.zjsmp;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;

import java.io.File;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/** /shop (buy menu), /sell, /sellall and /worth. Prices live in shop.yml and worth.yml. */
final class ShopManager {

    private static final int[] CATEGORY_SLOTS = {10, 11, 12, 13, 14, 15, 16};

    private final ZJSMP plugin;
    private YamlConfiguration shop;
    private final Map<Material, Double> worth = new HashMap<>();

    ShopManager(ZJSMP plugin) {
        this.plugin = plugin;
        reload();
    }

    void reload() {
        shop = YamlConfiguration.loadConfiguration(new File(plugin.getDataFolder(), "shop.yml"));
        worth.clear();
        YamlConfiguration w = YamlConfiguration.loadConfiguration(new File(plugin.getDataFolder(), "worth.yml"));
        ConfigurationSection s = w.getConfigurationSection("worth");
        if (s == null) return;
        for (String key : s.getKeys(false)) {
            Material m = Material.matchMaterial(key);
            if (m != null) worth.put(m, s.getDouble(key));
        }
    }

    double worth(Material m) {
        return worth.getOrDefault(m, 0.0);
    }

    // ------------------------------------------------------------ helpers

    ItemStack named(Material m, String name, String... lore) {
        ItemStack item = new ItemStack(m);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(plugin.c(name).decoration(TextDecoration.ITALIC, false));
        meta.lore(Arrays.stream(lore).map(l -> plugin.c(l).decoration(TextDecoration.ITALIC, false)).toList());
        item.setItemMeta(meta);
        return item;
    }

    static void give(Player p, ItemStack stack) {
        Map<Integer, ItemStack> left = p.getInventory().addItem(stack);
        for (ItemStack it : left.values()) p.getWorld().dropItemNaturally(p.getLocation(), it);
    }

    // ------------------------------------------------------------ menus

    void openMain(Player p) {
        ConfigurationSection cats = shop.getConfigurationSection("categories");
        GuiHolder h = new GuiHolder(GuiHolder.Kind.SHOP_MAIN, "", 0);
        h.inventory = Bukkit.createInventory(h, 27, plugin.c("&8{server} Shop"));
        if (cats != null) {
            int i = 0;
            for (String key : cats.getKeys(false)) {
                if (i >= CATEGORY_SLOTS.length) break;
                Material icon = Material.matchMaterial(cats.getString(key + ".icon", "CHEST"));
                if (icon == null) icon = Material.CHEST;
                int slot = CATEGORY_SLOTS[i++];
                h.inventory.setItem(slot, named(icon, cats.getString(key + ".name", key), "&7Click to browse"));
                h.slots.put(slot, key);
            }
        }
        p.openInventory(h.inventory);
    }

    void openCategory(Player p, String cat) {
        ConfigurationSection items = shop.getConfigurationSection("categories." + cat + ".items");
        GuiHolder h = new GuiHolder(GuiHolder.Kind.SHOP_CATEGORY, cat, 0);
        h.inventory = Bukkit.createInventory(h, 54,
                plugin.c("&8" + shop.getString("categories." + cat + ".name", cat).replaceAll("&[0-9a-fk-or]", "")));
        if (items != null) {
            int slot = 0;
            for (String key : items.getKeys(false)) {
                if (slot >= 45) break;
                Material m = Material.matchMaterial(key);
                if (m == null) continue;
                double price = items.getDouble(key);
                String sell = worth(m) > 0 ? "&7Sells for: &a" + EconomyManager.money(worth(m)) : "&8Can't be sold";
                h.inventory.setItem(slot, named(m, "&f" + pretty(m),
                        "&7Price: &a" + EconomyManager.money(price) + " &8each", sell, "",
                        "&eClick &7to buy 1", "&eShift-click &7to buy 64"));
                h.slots.put(slot, m);
                slot++;
            }
        }
        h.inventory.setItem(49, named(Material.ARROW, "&cBack"));
        p.openInventory(h.inventory);
    }

    private static String pretty(Material m) {
        String[] parts = m.name().toLowerCase().split("_");
        StringBuilder sb = new StringBuilder();
        for (String s : parts) sb.append(Character.toUpperCase(s.charAt(0))).append(s.substring(1)).append(' ');
        return sb.toString().trim();
    }

    void handleClick(Player p, GuiHolder h, InventoryClickEvent e) {
        int slot = e.getSlot();
        Object o = h.slots.get(slot);
        if (h.kind == GuiHolder.Kind.SHOP_MAIN) {
            if (o instanceof String cat) openCategory(p, cat);
            return;
        }
        if (slot == 49) {
            openMain(p);
            return;
        }
        if (o instanceof Material m) buy(p, h.key, m, e.isShiftClick() ? 64 : 1);
    }

    private void buy(Player p, String cat, Material m, int amount) {
        double price = shop.getDouble("categories." + cat + ".items." + m.name(), -1);
        if (price < 0) return;
        double total = price * amount;
        if (!plugin.economy().take(p.getUniqueId(), total)) {
            plugin.send(p, "&cYou need &f" + EconomyManager.money(total) + "&c for that.");
            return;
        }
        give(p, new ItemStack(m, amount));
        plugin.send(p, "&7Bought &f" + amount + "x " + pretty(m) + " &7for &a" + EconomyManager.money(total) + "&7.");
    }

    // ------------------------------------------------------------ selling

    void sellHand(Player p) {
        ItemStack it = p.getInventory().getItemInMainHand();
        if (it.getType().isAir()) {
            plugin.send(p, "&cHold the item you want to sell.");
            return;
        }
        double w = worth(it.getType());
        if (w <= 0 || it.hasItemMeta()) {
            plugin.send(p, "&cThat item can't be sold.");
            return;
        }
        double total = w * it.getAmount();
        p.getInventory().setItemInMainHand(null);
        plugin.economy().add(p.getUniqueId(), total);
        plugin.send(p, "&7Sold &f" + it.getAmount() + "x " + pretty(it.getType()) + " &7for &a" + EconomyManager.money(total) + "&7.");
    }

    void sellAll(Player p) {
        PlayerInventory inv = p.getInventory();
        double total = 0;
        int count = 0;
        for (int i = 0; i < 36; i++) {
            ItemStack it = inv.getItem(i);
            if (it == null || it.getType().isAir() || it.hasItemMeta()) continue;
            double w = worth(it.getType());
            if (w <= 0) continue;
            total += w * it.getAmount();
            count += it.getAmount();
            inv.setItem(i, null);
        }
        if (count == 0) {
            plugin.send(p, "&cYou have nothing sellable in your inventory.");
            return;
        }
        plugin.economy().add(p.getUniqueId(), total);
        plugin.send(p, "&7Sold &f" + count + " items &7for &a" + EconomyManager.money(total) + "&7.");
    }

    void worthHand(Player p) {
        ItemStack it = p.getInventory().getItemInMainHand();
        if (it.getType().isAir()) {
            plugin.send(p, "&cHold an item to check its worth.");
            return;
        }
        double w = worth(it.getType());
        plugin.send(p, w > 0
                ? "&f" + pretty(it.getType()) + " &7is worth &a" + EconomyManager.money(w) + " &7each (&a"
                  + EconomyManager.money(w * it.getAmount()) + " &7for your stack)."
                : "&cThat item can't be sold.");
    }
}

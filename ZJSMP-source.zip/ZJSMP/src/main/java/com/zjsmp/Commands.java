package com.zjsmp;

import com.zjsmp.PunishmentManager.Punishment;
import com.zjsmp.PunishmentManager.Type;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

final class Commands implements TabExecutor {

    private static final Set<String> PLAYER_ARG = Set.of(
            "freeze", "invsee", "ban", "tempban", "mute", "tempmute", "warn", "kick",
            "unban", "unmute", "history", "report");

    private final ZJSMP plugin;
    private final Map<UUID, Long> cooldowns = new HashMap<>();

    Commands(ZJSMP plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        String n = cmd.getName().toLowerCase();
        switch (n) {
            case "zjsmp" -> admin(s, a);
            case "media" -> media(s);
            case "ranks" -> rankList(s);
            case "stafflist" -> plugin.staff().sendStaffList(s);
            case "staffmode" -> staffMode(s, a);
            case "vanish" -> vanish(s);
            case "freeze" -> freeze(s, a);
            case "staffchat" -> staffChat(s, a);
            case "helpop" -> helpop(s, a, false);
            case "report" -> helpop(s, a, true);
            case "invsee" -> invsee(s, a);
            case "ban" -> punish(s, n, Type.BAN, false, a);
            case "tempban" -> punish(s, n, Type.BAN, true, a);
            case "mute" -> punish(s, n, Type.MUTE, false, a);
            case "tempmute" -> punish(s, n, Type.MUTE, true, a);
            case "warn" -> punish(s, n, Type.WARN, false, a);
            case "kick" -> punish(s, n, Type.KICK, false, a);
            case "unban" -> unpunish(s, Type.BAN, a);
            case "unmute" -> unpunish(s, Type.MUTE, a);
            case "history" -> history(s, a);
            default -> { return false; }
        }
        return true;
    }

    // ------------------------------------------------------------ small commands

    private void media(CommandSender s) {
        for (String line : plugin.getConfig().getStringList("media.info")) {
            s.sendMessage(plugin.c(line));
        }
    }

    private void rankList(CommandSender s) {
        plugin.send(s, "&f{server} ranks");
        for (RankManager.Rank r : plugin.ranks().all()) {
            if (r.display().isEmpty()) continue;
            s.sendMessage(plugin.c(" &8- " + r.display() + " &8(&7" + r.id() + "&8)"));
        }
        s.sendMessage(plugin.c(" &8- " + plugin.getConfig().getString("media.badge", "") + " &8(&7see /media&8)"));
    }

    private void staffMode(CommandSender s, String[] a) {
        if (a.length >= 1 && s.hasPermission("zjsmp.admin")) {
            Player t = Bukkit.getPlayerExact(a[0]);
            if (t == null) { plugin.send(s, "&cPlayer not online."); return; }
            plugin.staff().toggle(t);
            plugin.send(s, "&7Toggled staff mode for &f" + t.getName() + "&7.");
            return;
        }
        if (!(s instanceof Player p)) { plugin.send(s, "&cPlayers only."); return; }
        plugin.staff().toggle(p);
    }

    private void vanish(CommandSender s) {
        if (!(s instanceof Player p)) { plugin.send(s, "&cPlayers only."); return; }
        if (!plugin.staff().inStaffMode(p)) {
            plugin.send(p, "&cYou can only vanish while in staff mode. Use &f/staffmode&c.");
            return;
        }
        plugin.staff().toggleVanish(p);
    }

    private void freeze(CommandSender s, String[] a) {
        if (a.length < 1) { plugin.send(s, "&cUsage: /freeze <player>"); return; }
        Player t = Bukkit.getPlayerExact(a[0]);
        if (t == null) { plugin.send(s, "&cPlayer not online."); return; }
        plugin.staff().toggleFreeze(s, t);
    }

    private void staffChat(CommandSender s, String[] a) {
        if (a.length == 0) {
            if (!(s instanceof Player p)) { plugin.send(s, "&cUsage: /sc <message>"); return; }
            if (!plugin.staff().staffChatToggle.add(p.getUniqueId())) {
                plugin.staff().staffChatToggle.remove(p.getUniqueId());
                plugin.send(p, "&cStaff chat toggle off.");
            } else {
                plugin.send(p, "&aStaff chat toggle on. Your messages go to staff only.");
            }
            return;
        }
        plugin.staff().staffChat(s, String.join(" ", a));
    }

    private void helpop(CommandSender s, String[] a, boolean report) {
        if (!(s instanceof Player p)) { plugin.send(s, "&cPlayers only."); return; }
        int min = report ? 2 : 1;
        if (a.length < min) {
            plugin.send(p, report ? "&cUsage: /report <player> <reason>" : "&cUsage: /helpop <message>");
            return;
        }
        long now = System.currentTimeMillis();
        long cd = plugin.getConfig().getLong("helpop-cooldown-seconds", 30) * 1000L;
        Long last = cooldowns.get(p.getUniqueId());
        if (last != null && now - last < cd && !p.hasPermission("zjsmp.alerts")) {
            plugin.send(p, "&cPlease wait before sending another request.");
            return;
        }
        cooldowns.put(p.getUniqueId(), now);

        String text = report
                ? "&8[&cReport&8] &f" + p.getName() + " &7reported &f" + a[0] + "&7: &f" + String.join(" ", Arrays.copyOfRange(a, 1, a.length))
                : "&8[&eHelpOp&8] &f" + p.getName() + "&7: &f" + String.join(" ", a);
        plugin.staff().alert(text);
        plugin.send(p, report ? "&aYour report was sent to online staff." : "&aYour message was sent to online staff.");
    }

    private void invsee(CommandSender s, String[] a) {
        if (!(s instanceof Player p)) { plugin.send(s, "&cPlayers only."); return; }
        if (a.length < 1) { plugin.send(p, "&cUsage: /invsee <player>"); return; }
        Player t = Bukkit.getPlayerExact(a[0]);
        if (t == null) { plugin.send(p, "&cPlayer not online."); return; }
        p.openInventory(t.getInventory());
    }

    // ------------------------------------------------------------ punishments

    private OfflinePlayer resolve(String name) {
        Player p = Bukkit.getPlayerExact(name);
        return p != null ? p : Bukkit.getOfflinePlayerIfCached(name);
    }

    private void punish(CommandSender s, String label, Type type, boolean temp, String[] a) {
        int min = temp ? 2 : 1;
        if (a.length < min) {
            plugin.send(s, "&cUsage: /" + label + " <player> " + (temp ? "<time e.g. 30m, 2h, 5d> " : "") + "[reason]");
            return;
        }
        OfflinePlayer target = resolve(a[0]);
        if (target == null) { plugin.send(s, "&cUnknown player &f" + a[0] + "&c (they must have joined before)."); return; }

        Player online = target.getPlayer();
        boolean exempt = online != null ? online.hasPermission("zjsmp.exempt") : plugin.ranks().isStaff(target.getUniqueId());
        if (exempt && s instanceof Player && !s.hasPermission("zjsmp.exempt.bypass")) {
            plugin.send(s, "&cYou can't punish that player.");
            return;
        }

        long duration = 0;
        int reasonFrom = 1;
        if (temp) {
            duration = PunishmentManager.parseDuration(a[1]);
            if (duration <= 0) { plugin.send(s, "&cInvalid time. Use e.g. &f30m&c, &f2h&c, &f5d&c, &f1d12h&c."); return; }
            reasonFrom = 2;
        }
        if (type == Type.KICK && online == null) { plugin.send(s, "&cThat player isn't online."); return; }

        String reason = a.length > reasonFrom
                ? String.join(" ", Arrays.copyOfRange(a, reasonFrom, a.length))
                : plugin.getConfig().getString("punishments.default-reason", "No reason provided");
        String by = s instanceof Player ? s.getName() : "Console";
        String name = target.getName() != null ? target.getName() : a[0];

        Punishment p = plugin.punishments().add(type, target.getUniqueId(), name, by, reason, duration);
        String len = duration > 0 ? " &7for &f" + PunishmentManager.formatDuration(duration) : "";

        switch (type) {
            case BAN -> {
                if (online != null) online.kick(plugin.punishments().banScreen(p));
            }
            case MUTE -> {
                if (online != null) plugin.send(online, "&cYou have been muted" + len.replace("&7", "&c") + "&c. &7Reason: &f" + reason);
            }
            case WARN -> {
                if (online != null) plugin.send(online, "&eYou have been warned: &f" + reason);
            }
            case KICK -> online.kick(plugin.c("&b&l{server}\n\n&cYou were kicked\n&7Reason: &f" + reason));
        }

        String verb = switch (type) {
            case BAN -> "banned";
            case MUTE -> "muted";
            case WARN -> "warned";
            case KICK -> "kicked";
        };
        plugin.staff().alert("&f" + by + " &7" + verb + " &f" + name + len + "&7: &f" + reason + " &8(#" + p.id + ")");
    }

    private void unpunish(CommandSender s, Type type, String[] a) {
        if (a.length < 1) { plugin.send(s, "&cUsage: /" + (type == Type.BAN ? "unban" : "unmute") + " <player>"); return; }
        OfflinePlayer t = resolve(a[0]);
        if (t == null) { plugin.send(s, "&cUnknown player &f" + a[0]); return; }
        if (plugin.punishments().revoke(t.getUniqueId(), type)) {
            String by = s instanceof Player ? s.getName() : "Console";
            plugin.staff().alert("&f" + by + " &7removed the " + type.name().toLowerCase() + " on &f" + a[0] + "&7.");
            if (t.getPlayer() != null && type == Type.MUTE) plugin.send(t.getPlayer(), "&aYou have been unmuted.");
        } else {
            plugin.send(s, "&cThat player has no active " + type.name().toLowerCase() + ".");
        }
    }

    private void history(CommandSender s, String[] a) {
        UUID id = null;
        if (a.length >= 1) {
            OfflinePlayer t = resolve(a[0]);
            if (t == null) { plugin.send(s, "&cUnknown player &f" + a[0]); return; }
            id = t.getUniqueId();
        }
        List<Punishment> list = plugin.punishments().history(id, 10);
        plugin.send(s, "&fLast " + list.size() + " punishments" + (id != null ? " for &b" + a[0] : ""));
        long now = System.currentTimeMillis();
        for (Punishment p : list) {
            String state = (p.type == Type.BAN || p.type == Type.MUTE) ? (p.isActive() ? " &a[ACTIVE]" : " &7[ended]") : "";
            s.sendMessage(plugin.c(" &8#" + p.id + " &e" + p.type + " &f" + p.targetName + " &7by &f" + p.by
                    + " &8- &7" + p.reason + " &8(" + PunishmentManager.formatDuration(now - p.created) + " ago)" + state));
        }
    }

    // ------------------------------------------------------------ /zjsmp

    private boolean need(CommandSender s, String perm) {
        if (s.hasPermission(perm)) return true;
        plugin.send(s, "&cYou don't have permission to do that.");
        return false;
    }

    private void admin(CommandSender s, String[] a) {
        if (a.length == 0) { help(s); return; }
        switch (a[0].toLowerCase()) {
            case "reload" -> {
                if (!need(s, "zjsmp.reload")) return;
                plugin.reloadAll();
                plugin.send(s, "&aReloaded {server} config.");
            }
            case "rank" -> {
                if (!need(s, "zjsmp.rank")) return;
                if (a.length >= 2 && a[1].equalsIgnoreCase("list")) { rankList(s); return; }
                if (a.length < 4 || !a[1].equalsIgnoreCase("set")) {
                    plugin.send(s, "&cUsage: /zjsmp rank set <player> <rank>  |  /zjsmp rank list");
                    return;
                }
                OfflinePlayer t = resolve(a[2]);
                RankManager.Rank r = plugin.ranks().get(a[3]);
                if (t == null) { plugin.send(s, "&cUnknown player (they must have joined before)."); return; }
                if (r == null) { plugin.send(s, "&cUnknown rank. Use /zjsmp rank list"); return; }
                plugin.ranks().setRank(t.getUniqueId(), r.id());
                refresh(t);
                plugin.send(s, "&7Set &f" + a[2] + "&7's rank to &f" + r.id() + "&7.");
            }
            case "media" -> {
                if (!need(s, "zjsmp.mediaadmin")) return;
                if (a.length < 4 || !a[1].equalsIgnoreCase("set")
                        || !Set.of("none", "media", "plus").contains(a[3].toLowerCase())) {
                    plugin.send(s, "&cUsage: /zjsmp media set <player> <none|media|plus>");
                    return;
                }
                OfflinePlayer t = resolve(a[2]);
                if (t == null) { plugin.send(s, "&cUnknown player (they must have joined before)."); return; }
                plugin.ranks().setMedia(t.getUniqueId(), a[3]);
                refresh(t);
                plugin.send(s, "&7Set &f" + a[2] + "&7's media status to &d" + a[3].toLowerCase() + "&7.");
            }
            default -> help(s);
        }
    }

    private void refresh(OfflinePlayer t) {
        Player online = t.getPlayer();
        if (online != null) {
            plugin.ranks().apply(online);
            plugin.staff().refreshVisibility();
        }
    }

    private void help(CommandSender s) {
        plugin.send(s, "&f{server} admin");
        s.sendMessage(Component.text(" /zjsmp reload", NamedTextColor.GRAY));
        s.sendMessage(Component.text(" /zjsmp rank set <player> <rank> | list", NamedTextColor.GRAY));
        s.sendMessage(Component.text(" /zjsmp media set <player> <none|media|plus>", NamedTextColor.GRAY));
    }

    // ------------------------------------------------------------ tab complete

    @Override
    public List<String> onTabComplete(CommandSender s, Command cmd, String label, String[] a) {
        String n = cmd.getName().toLowerCase();
        String last = a[a.length - 1].toLowerCase();
        List<String> out = new ArrayList<>();

        if (n.equals("zjsmp")) {
            if (a.length == 1) out.addAll(List.of("reload", "rank", "media"));
            else if (a.length == 2 && (a[0].equalsIgnoreCase("rank"))) out.addAll(List.of("set", "list"));
            else if (a.length == 2 && (a[0].equalsIgnoreCase("media"))) out.add("set");
            else if (a.length == 3) Bukkit.getOnlinePlayers().forEach(p -> out.add(p.getName()));
            else if (a.length == 4 && a[0].equalsIgnoreCase("rank")) plugin.ranks().all().forEach(r -> out.add(r.id()));
            else if (a.length == 4 && a[0].equalsIgnoreCase("media")) out.addAll(List.of("none", "media", "plus"));
        } else if (n.equals("staffmode") && a.length == 1 && s.hasPermission("zjsmp.admin")) {
            Bukkit.getOnlinePlayers().forEach(p -> out.add(p.getName()));
        } else if (PLAYER_ARG.contains(n) && a.length == 1) {
            Bukkit.getOnlinePlayers().forEach(p -> out.add(p.getName()));
        }
        out.removeIf(x -> !x.toLowerCase().startsWith(last));
        return out;
    }
}

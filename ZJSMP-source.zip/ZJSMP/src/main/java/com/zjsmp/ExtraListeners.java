package com.zjsmp;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;

import java.util.Objects;

/** Menu clicks and kill/death counters. */
final class ExtraListeners implements Listener {

    private final ZJSMP plugin;

    ExtraListeners(ZJSMP plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof GuiHolder h)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (!Objects.equals(e.getClickedInventory(), e.getView().getTopInventory())) return;
        switch (h.kind) {
            case SHOP_MAIN, SHOP_CATEGORY -> plugin.shop().handleClick(p, h, e);
            case AUCTION -> plugin.auctions().handleClick(p, h, e);
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof GuiHolder) e.setCancelled(true);
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        Player victim = e.getEntity();
        plugin.economy().addDeath(victim.getUniqueId());
        Player killer = victim.getKiller();
        if (killer != null && !killer.equals(victim)) plugin.economy().addKill(killer.getUniqueId());
    }
}

package com.zjsmp;

import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Money, shards, kills, deaths, playtime and the keyall timer. Stored in economy.yml. */
final class EconomyManager {

    static final class Account {
        final UUID id;
        String name = "?";
        double money;
        long shards;
        int kills;
        int deaths;
        long playtime; // seconds, finished sessions only

        Account(UUID id) { this.id = id; }
    }

    private final ZJSMP plugin;
    private final File file;
    private final Map<UUID, Account> accounts = new ConcurrentHashMap<>();
    private final Map<UUID, Long> session = new ConcurrentHashMap<>();
    private long nextKeyall;
    private volatile boolean dirty;

    EconomyManager(ZJSMP plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "economy.yml");
        load();
    }

    private void load() {
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        nextKeyall = y.getLong("next-keyall", 0);
        ConfigurationSection s = y.getConfigurationSection("players");
        if (s == null) return;
        for (String key : s.getKeys(false)) {
            try {
                UUID id = UUID.fromString(key);
                ConfigurationSection c = s.getConfigurationSection(key);
                if (c == null) continue;
                Account a = new Account(id);
                a.name = c.getString("name", "?");
                a.money = c.getDouble("money");
                a.shards = c.getLong("shards");
                a.kills = c.getInt("kills");
                a.deaths = c.getInt("deaths");
                a.playtime = c.getLong("playtime");
                accounts.put(id, a);
            } catch (IllegalArgumentException ignored) { }
        }
    }

    synchronized void save() {
        YamlConfiguration y = new YamlConfiguration();
        y.set("next-keyall", nextKeyall);
        for (Account a : accounts.values()) {
            String b = "players." + a.id + ".";
            y.set(b + "name", a.name);
            y.set(b + "money", a.money);
            y.set(b + "shards", a.shards);
            y.set(b + "kills", a.kills);
            y.set(b + "deaths", a.deaths);
            y.set(b + "playtime", a.playtime);
        }
        try {
            plugin.getDataFolder().mkdirs();
            y.save(file);
            dirty = false;
        } catch (IOException e) {
            plugin.getLogger().warning("Could not save economy.yml: " + e.getMessage());
        }
    }

    void saveIfDirty() {
        if (dirty) save();
    }

    // ------------------------------------------------------------ accounts

    Account acc(UUID id) {
        return accounts.computeIfAbsent(id, k -> {
            Account a = new Account(k);
            a.money = plugin.getConfig().getDouble("economy.starting-balance", 0);
            dirty = true;
            return a;
        });
    }

    UUID find(String name) {
        Player online = Bukkit.getPlayerExact(name);
        if (online != null) return online.getUniqueId();
        for (Account a : accounts.values()) {
            if (a.name.equalsIgnoreCase(name)) return a.id;
        }
        return null;
    }

    void onJoin(Player p) {
        Account a = acc(p.getUniqueId());
        a.name = p.getName();
        session.put(p.getUniqueId(), System.currentTimeMillis());
        dirty = true;
    }

    void onQuit(Player p) {
        Long start = session.remove(p.getUniqueId());
        if (start != null) acc(p.getUniqueId()).playtime += (System.currentTimeMillis() - start) / 1000;
        save();
    }

    void shutdown() {
        long now = System.currentTimeMillis();
        for (Map.Entry<UUID, Long> e : session.entrySet()) {
            acc(e.getKey()).playtime += (now - e.getValue()) / 1000;
        }
        session.clear();
        save();
    }

    long playtimeSeconds(UUID id) {
        Long start = session.get(id);
        long extra = start == null ? 0 : (System.currentTimeMillis() - start) / 1000;
        return acc(id).playtime + extra;
    }

    // ------------------------------------------------------------ money

    private static double round(double v) {
        return Math.round(v * 100.0) / 100.0;
    }

    double balance(UUID id) { return acc(id).money; }

    boolean has(UUID id, double amount) { return acc(id).money + 1e-9 >= amount; }

    void add(UUID id, double amount) {
        Account a = acc(id);
        a.money = round(a.money + amount);
        dirty = true;
    }

    boolean take(UUID id, double amount) {
        if (!has(id, amount)) return false;
        Account a = acc(id);
        a.money = round(a.money - amount);
        dirty = true;
        return true;
    }

    void set(UUID id, double amount) {
        acc(id).money = round(amount);
        dirty = true;
    }

    void setShards(UUID id, long v) { acc(id).shards = Math.max(0, v); dirty = true; }
    void addShards(UUID id, long v) { setShards(id, acc(id).shards + v); }
    void addKill(UUID id) { acc(id).kills++; dirty = true; }
    void addDeath(UUID id) { acc(id).deaths++; dirty = true; }

    List<Account> top(int n) {
        return accounts.values().stream()
                .sorted(Comparator.comparingDouble((Account a) -> a.money).reversed())
                .limit(n).toList();
    }

    // ------------------------------------------------------------ keyall

    /** Called once a second. */
    void tick() {
        int mins = plugin.getConfig().getInt("keyall.interval-minutes", 60);
        if (mins <= 0) return;
        long now = System.currentTimeMillis();
        if (nextKeyall == 0) {
            nextKeyall = now + mins * 60_000L;
            dirty = true;
            return;
        }
        if (now < nextKeyall) return;
        nextKeyall = now + mins * 60_000L;
        dirty = true;
        Bukkit.broadcast(plugin.c(plugin.getConfig().getString("keyall.message", "{prefix}&aKeyall!")));
        List<String> cmds = plugin.getConfig().getStringList("keyall.commands");
        for (Player p : Bukkit.getOnlinePlayers()) {
            for (String c : cmds) {
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), c.replace("%player%", p.getName()));
            }
        }
    }

    String keyallCountdown() {
        if (plugin.getConfig().getInt("keyall.interval-minutes", 60) <= 0 || nextKeyall == 0) return "Off";
        long s = Math.max(0, (nextKeyall - System.currentTimeMillis()) / 1000);
        long h = s / 3600, m = (s % 3600) / 60, sec = s % 60;
        return h > 0 ? String.format("%d:%02d:%02d", h, m, sec) : String.format("%02d:%02d", m, sec);
    }

    // ------------------------------------------------------------ formatting

    static String money(double v) {
        return "$" + String.format(Locale.US, "%,.2f", v);
    }

    static String nice(double v) {
        String[] suf = {"", "K", "M", "B", "T"};
        int i = 0;
        double x = v;
        while (Math.abs(x) >= 1000 && i < suf.length - 1) {
            x /= 1000;
            i++;
        }
        String s = x == Math.floor(x)
                ? String.valueOf((long) x)
                : String.format(Locale.US, "%.2f", x).replaceAll("0+$", "").replaceAll("\\.$", "");
        return s + suf[i];
    }

    /** Accepts 1500, 1.5k, 2m, 3b, 1t. Returns NaN when invalid or not positive. */
    static double parse(String in) {
        String s = in.toLowerCase(Locale.ROOT).replace(",", "").replace("$", "").trim();
        if (s.isEmpty()) return Double.NaN;
        double mult = 1;
        char last = s.charAt(s.length() - 1);
        switch (last) {
            case 'k' -> mult = 1e3;
            case 'm' -> mult = 1e6;
            case 'b' -> mult = 1e9;
            case 't' -> mult = 1e12;
            default -> { }
        }
        if (mult != 1) s = s.substring(0, s.length() - 1);
        try {
            double v = Double.parseDouble(s) * mult;
            return (Double.isNaN(v) || Double.isInfinite(v) || v <= 0) ? Double.NaN : v;
        } catch (NumberFormatException e) {
            return Double.NaN;
        }
    }

    static String time(long seconds) {
        long d = seconds / 86_400, h = (seconds % 86_400) / 3600, m = (seconds % 3600) / 60;
        if (d > 0) return d + "d " + h + "h";
        if (h > 0) return h + "h " + m + "m";
        return m + "m";
    }
}

# ZJSMP core plugin (no dependencies)

Paper 26.2 · Java 25 · only needs the Paper API (not bundled). No LuckPerms, ProtocolLib or PlaceholderAPI.

## Build
Needs JDK 25 + Maven:

    mvn clean package

Jar ends up at `target/ZJSMP.jar`.

## Install (SquidServers)
1. Server must run Paper 26.2 and a Java 25 runtime (check the Java/Startup option in the panel).
2. Upload `ZJSMP.jar` to `/plugins`, restart.
3. Give yourself Owner from the console (you must have joined once):
       zjsmp rank set YourName owner
4. Edit `plugins/ZJSMP/config.yml`, then `/zjsmp reload`.

## Staff roles (helper < mod < sr-mod < admin < manager < owner)
`/zjsmp rank set <player> <rank>`, `/zjsmp rank list`. Edit names, colors, weights and permissions in config.yml.
Rank shows in chat, tab list (sorted by weight) and above the head.

## Media
`/zjsmp media set <player> <none|media|plus>` gives the badge in chat/tab/join messages.
`/media` shows the requirements text from config.yml (`media.info`). Media is separate from staff ranks, so staff can also be Media.
Gives permission nodes `rank.media` / `rank.media.plus` like DonutSMP.
Swap the badge text for 📹 in `media.badge` if your players' clients show it.

## Staff tools
/staffmode (/staff) hotbar: vanish, freeze, staff list, better view, random tp. Inventory is saved and restored (survives restarts).
/vanish, /freeze, /staffchat (/sc), /stafflist, /invsee, /helpop, /report
/ban /tempban /unban /mute /tempmute /unmute /warn /kick /history

All branding comes from `server-name` and `prefix` in config.yml (default ZJSMP).

## v1.1 additions (still no dependencies)
- Built-in placeholders (replaces PlaceholderAPI): %economy_money% %economy_nicestMoney% %economy_shards% %economy_kills% %economy_deaths% %economy_playtime% %economy_keyall_countdown% %economy_ping% %player_name% %zjsmp_rank% %zjsmp_media% %server_online%
- Sidebar scoreboard (config.yml `scoreboard:`), toggle with /sb
- Economy: /bal /pay /baltop, admin /eco give|take|set|reset, /eco shards ...
- /home /sethome /delhome /homes /spawn /setspawn /tpa /tpahere /tpaccept /tpdeny /rtp /warp /warps /setwarp /delwarp
- /shop (menu), /sell, /sellall, /worth - edit shop.yml and worth.yml
- /ah (auction house), /ah sell <price>, /ah claim - 5% tax, 48h listings
